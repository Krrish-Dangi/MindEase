import React from 'react';

const Footer = () => {
  return (
    <footer className="bg-white pt-16 pb-8">
      <div className="container mx-auto px-6">
        
        {/* =================================================================== */}
        {/* == THIS IS THE MAIN GRID CONTAINER THAT HOLDS ALL THE COLUMNS == */}
        {/* =================================================================== */}
        <div className="grid md:grid-cols-2 lg:grid-cols-6 gap-8">
          
          {/* Column 1: Logo & Mission (Takes up 2 slots on large screens) */}
          <div className="lg:col-span-2">
            <h2 className="text-xl font-bold text-slate-800 mb-2">MindHaven</h2>
            <p className="text-slate-500 pr-10">
              Calm, confidential support for students in higher education.
            </p>
          </div>

          {/* Column 2: Company */}
          <div>
            <h3 className="font-bold text-slate-800 mb-4">Company</h3>
            <ul className="space-y-3 text-slate-600">
              <li><a href="#" className="hover:text-blue-600">About</a></li>
              <li><a href="#" className="hover:text-blue-600">Careers</a></li>
              <li><a href="#" className="hover:text-blue-600">Contact</a></li>
            </ul>
          </div>

          {/* Column 3: Legal */}
          <div>
            <h3 className="font-bold text-slate-800 mb-4">Legal</h3>
            <ul className="space-y-3 text-slate-600">
              <li><a href="#" className="hover:text-blue-600">Privacy</a></li>
              <li><a href="#" className="hover:text-blue-600">Terms</a></li>
              <li><a href="#" className="hover:text-blue-600">Accessibility</a></li>
            </ul>
          </div>
          
          {/* Column 4: Resources */}
           <div>
            <h3 className="font-bold text-slate-800 mb-4">Resources</h3>
            <ul className="space-y-3 text-slate-600">
              <li><a href="#" className="hover:text-blue-600">Blog</a></li>
              <li><a href="#" className="hover:text-blue-600">Guides</a></li>
              <li><a href="#" className="hover:text-blue-600">Help Center</a></li>
            </ul>
          </div>

          {/* Column 5: Socials */}
          <div>
            <h3 className="font-bold text-slate-800 mb-4">Socials</h3>
            <ul className="space-y-3 text-slate-600">
              <li>
                <a 
                  href="https://x.com/_Frosty_OP" 
                  className="hover:text-blue-600" 
                  target="_blank" 
                  rel="noopener noreferrer"
                >
                  X
                </a>
              </li>
              <li>
                <a 
                  href="https://www.linkedin.com/in/krrish-dangi-a0725a33b/" 
                  className="hover:text-blue-600" 
                  target="_blank" 
                  rel="noopener noreferrer"
                >
                  LinkedIn
                </a>
              </li>
              <li>
                <a 
                  href="https://www.instagram.com/krrish._.dangi__/?__pwa=1" 
                  className="hover:text-blue-600" 
                  target="_blank" 
                  rel="noopener noreferrer"
                >
                  Instagram
                </a>
              </li>
            </ul>
          </div>
          
        </div> {/* <-- THIS CLOSING </div> TAG FOR THE GRID IS CRITICAL */}
        
        {/* This is the bottom part with copyright info */}
        <div className="mt-12 border-t border-slate-200 pt-6 flex flex-col md:flex-row justify-between items-center text-sm text-slate-500">
          <p>© 2025 MindHaven. All rights reserved.</p>
          <div className="flex gap-4 mt-4 md:mt-0">
             <a href="#" className="hover:text-blue-600">Wellness-first</a>
             <a href="#" className="hover:text-blue-600">Private by default</a>
          </div>
        </div>
      </div>
    </footer>
  )
}

export default Footer;