import React, { useState } from 'react';
import { FaRobot, FaUsers, FaBook, FaUserLock } from 'react-icons/fa';

// Import the reusable Modal component
import Modal from './Modal';

// This is a small helper component to keep our code clean
const FeatureCard = ({ icon, title, linkText, children, onLinkClick }) => (
  <div className="bg-slate-50 p-6 rounded-lg text-center border border-slate-200">
    <div className="flex justify-center text-blue-600 mb-4">{icon}</div>
    <h3 className="text-xl font-bold text-slate-800 mb-2">{title}</h3>
    <p className="text-slate-600 mb-4">{children}</p>
    <button onClick={onLinkClick} className="font-semibold text-blue-600 hover:text-blue-800">
      {linkText} →
    </button>
  </div>
);


const WhyMindHaven = () => {
  // State to manage the modal's visibility
  const [isModalOpen, setIsModalOpen] = useState(false);
  // State to hold the content (title and text) for the modal
  const [modalContent, setModalContent] = useState({ title: '', text: '' });

  // 1. DATA: We put all information for the four cards in this array.
  const features = [
    {
      id: 'ai-support',
      icon: <FaRobot size={32} />,
      title: 'AI Support',
      description: 'Chat anytime for guided exercises, mood tracking, and gentle check-ins.',
      linkText: 'Learn more',
      modalData: {
        title: 'AI-Powered Guidance',
        text: 'Our AI Assistant provides immediate, 24/7 support. It can help you create a study plan, guide you through a breathing exercise, or just listen. It learns from your needs to suggest relevant resources from the hub, all within a safe and private chat.'
      }
    },
    {
      id: 'peer-community',
      icon: <FaUsers size={32} />,
      title: 'Peer Community',
      description: 'Find moderated groups and events where students support each other.',
      linkText: 'Learn more',
      modalData: {
        title: 'Connect with Your Peers',
        text: 'Join safe, anonymous, and moderated group chats and forums. Share experiences, offer support, and connect with other students who understand what you\'re going through. It\'s a space to feel heard and less alone.'
      }
    },
    {
      id: 'resource-hub',
      icon: <FaBook size={32} />,
      title: 'Resource Hub',
      description: 'Campus-specific articles, workshops, and self-care toolkits in one place.',
      linkText: 'Learn more',
      modalData: {
        title: 'A Library of Wellness Tools',
        text: 'The Resource Hub is a curated collection of articles, videos, workshops, and tools tailored to your campus. Find information on stress management, academic skills, financial aid, and much more, all vetted by professionals.'
      }
    },
    {
      id: 'confidential-booking',
      icon: <FaUserLock size={32} />,
      title: 'Confidential Booking',
      description: 'Schedule with licensed professionals—on campus or online—privately.',
      linkText: 'Learn more',
      modalData: {
        title: 'Private & Professional Help',
        text: 'Easily and confidentially browse the profiles of licensed therapists and counselors available to you. See their schedules and book an appointment for an online or in-person session at a time that works for you, all without leaving the app.'
      }
    }
  ];

  // 2. LOGIC: A function to open the modal with the right content
  const openModal = (data) => {
    setModalContent(data);
    setIsModalOpen(true);
  };

  // A function to close the modal
  const closeModal = () => {
    setIsModalOpen(false);
  };

  return (
    <>
      <section id="features-section" className="container mx-auto px-6 py-16">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-extrabold text-slate-900 mb-2">Why MindHaven</h2>
          <p className="text-slate-600 text-lg">Designed for students—calm, private, and ready when you are.</p>
        </div>

        {/* 3. RENDERING: We map over the data to create the four cards dynamically */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature) => (
            <FeatureCard
              key={feature.id}
              icon={feature.icon}
              title={feature.title}
              linkText={feature.linkText}
              onLinkClick={() => openModal(feature.modalData)}
            >
              {feature.description}
            </FeatureCard>
          ))}
        </div>
      </section>

      {/* 4. THE MODAL: It sits here, waiting to be opened. */}
      <Modal isOpen={isModalOpen} onClose={closeModal}>
        <h2 className="text-3xl font-bold text-slate-800 mb-4">{modalContent.title}</h2>
        <p className="text-slate-600 leading-relaxed">{modalContent.text}</p>
      </Modal>
    </>
  );
};

export default WhyMindHaven;