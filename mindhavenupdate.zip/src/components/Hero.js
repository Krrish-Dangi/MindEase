import React from 'react';
import { FaShieldAlt, FaLanguage, FaRegClock } from 'react-icons/fa';
import campusPhoto from '../assets/campus-photo.jpg'; 
import { Link } from 'react-router-dom';

const Hero = () => {
  return (
    <section className="container mx-auto px-6 py-16">
      <div className="bg-white p-8 rounded-2xl shadow-lg border border-slate-200">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <span className="font-semibold text-sm text-blue-600 bg-blue-100 py-1 px-3 rounded-full">
              For higher-education students
            </span>
            <h1 className="text-4xl md:text-5xl font-extrabold text-slate-900 mt-4 mb-6">
              Accessible, stigma-free mental health support
            </h1>
            <p className="text-slate-600 text-lg mb-8">
              Connect with AI support, peer communities, campus resources, and confidential counselors—tailored to your campus culture.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 mb-8">

              {/* ======================================================= */}
              {/* == THE CHANGE IS HERE: "/signup" is now "/app/dashboard" == */}
              {/* ======================================================= */}
              <Link 
                to="/app/dashboard" 
                className="block text-center bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-lg text-lg transition duration-300 shadow-lg"
              >
                Get Started
              </Link>

              <button className="bg-white hover:bg-slate-100 text-slate-800 font-bold py-3 px-6 rounded-lg text-lg transition duration-300 border border-slate-300 shadow-md">
                View demo
              </button>
            </div>
            <div className="flex items-center gap-6 text-slate-600">
              <div className="flex items-center gap-2"><FaShieldAlt className="text-blue-500" /> Confidential</div>
              <div className="flex items-center gap-2"><FaLanguage className="text-blue-500" /> Multilingual</div>
              <div className="flex items-center gap-2"><FaRegClock className="text-blue-500" /> 24/7 AI</div>
            </div>
          </div>
          <div>
            <img src={campusPhoto} alt="Welcoming campus scene" className="rounded-xl w-full h-full object-cover" />
            <p className="text-center text-sm text-slate-500 mt-2">
              A welcoming campus scene to feel relatable and calm.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;