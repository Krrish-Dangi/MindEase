import React from 'react';
import { NavLink, Link } from 'react-router-dom';
import { FaTachometerAlt, FaRobot, FaUsers, FaBook, FaCalendarCheck } from 'react-icons/fa';

// Placeholder user data
const user = {
  name: 'Aanya',
  campus: 'North Ridge',
  avatarUrl: 'https://i.pravatar.cc/150?u=aanya'
};

const Sidebar = () => {
  const getNavLinkClass = ({ isActive }) => {
    return isActive
      ? 'flex items-center p-3 rounded-lg bg-blue-600 text-white shadow-md'
      : 'flex items-center p-3 rounded-lg text-gray-700 hover:bg-slate-200';
  };

  return (
    <aside className="w-64 bg-slate-100 h-screen flex flex-col p-4 border-r border-slate-200 fixed top-0 left-0">
      <Link to="/app/dashboard" className="text-2xl font-bold text-slate-800 mb-8 pl-2">
        MindHaven
      </Link>
      
      <div className="flex items-center mb-8">
        <img src={user.avatarUrl} alt="User avatar" className="w-12 h-12 rounded-full mr-3" />
        <div>
          <p className="font-bold text-slate-800">Hi, {user.name}</p>
          <p className="text-sm text-slate-500">{user.campus}</p>
        </div>
      </div>

      <nav className="flex-grow">
        <p className="text-sm font-semibold text-slate-500 mb-2 pl-3">Main</p>
        <ul className="space-y-2">
          <li><NavLink to="/app/dashboard" className={getNavLinkClass}><FaTachometerAlt className="mr-3" /> Dashboard</NavLink></li>
          <li><NavLink to="/app/ai-support" className={getNavLinkClass}><FaRobot className="mr-3" /> AI Support</NavLink></li>
          <li><NavLink to="/app/peer-support" className={getNavLinkClass}><FaUsers className="mr-3" /> Peer Support</NavLink></li>
          <li><NavLink to="/app/resource-hub" className={getNavLinkClass}><FaBook className="mr-3" /> Resource Hub</NavLink></li>
          <li><NavLink to="/app/booking-system" className={getNavLinkClass}><FaCalendarCheck className="mr-3" /> Booking System</NavLink></li>
        </ul>
      </nav>

      <div>
        <Link to="/" className="w-full text-center p-3 rounded-lg text-red-600 hover:bg-red-100 font-bold block">
          Logout
        </Link>
      </div>
    </aside>
  );
};

export default Sidebar;