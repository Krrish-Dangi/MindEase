import React from 'react';
import studentIllustration from '../assets/student-illustration.jpg'; // <-- IMPORTANT: Make sure this path is correct

const HowItWorks = () => {
  return (
    <section id="how-it-works-section" className="bg-slate-50 py-16">
      <div className="container mx-auto px-6">
        <div className="text-left mb-12">
          <h2 className="text-4xl font-extrabold text-slate-900 mb-2">How it works</h2>
          <p className="text-slate-600 text-lg">Three simple steps to start feeling better.</p>
        </div>

        <div className="grid md:grid-cols-2 gap-16 items-start">
          
          {/* Left Column: Steps */}
        <div className="flex flex-col gap-8 h-full">
            <div className="bg-white p-9 rounded-lg border border-slate-200">
              <h3 className="text-xl font-bold text-slate-800 mb-2">1. Create your space</h3>
              <p className="text-slate-600">Set preferences like language, modality, and focus areas. We personalize content to your campus.</p>
            </div>
            <div className="bg-white p-9 rounded-lg border border-slate-200">
              <h3 className="text-xl font-bold text-slate-800 mb-2">2. Explore support</h3>
              <p className="text-slate-600">Try AI tools, join peer circles, and read expert guides crafted for students.</p>
            </div>
             <div className="bg-white p-9 rounded-lg border border-slate-200">
              <h3 className="text-xl font-bold text-slate-800 mb-2">3. Book when ready</h3>
              <p className="text-slate-600">Confidentially schedule with licensed counselors at times that work for you.</p>
            </div>
          </div>

          {/* Right Column: Image */}
          <div className="sticky top-24">
             <img src={studentIllustration} alt="Student-focused illustration" className="rounded-xl w-full h-full object-cover" />
            <p className="text-center text-sm text-slate-500 mt-2">
              Subtle, student-focused illustration to keep the page calm.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;