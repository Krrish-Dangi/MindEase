import React from 'react';
import { FaTimes } from 'react-icons/fa';

const Modal = ({ isOpen, onClose, children }) => {
  // This is the most important line: if isOpen is false, the component returns nothing.
  if (!isOpen) return null;

  return (
    // Main overlay
    <div 
      className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50"
      onClick={onClose} // This allows closing the modal by clicking the background
    >
      {/* Modal content box */}
      <div 
        className="bg-white rounded-xl shadow-2xl p-6 md:p-8 max-w-2xl w-11/12 relative animate-fade-in-up"
        onClick={e => e.stopPropagation()} // This prevents a click inside the modal from closing it
      >
        {/* Close button */}
        <button 
          onClick={onClose} 
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
        >
          <FaTimes size={24} />
        </button>

        {/* This is where the title and text will be displayed */}
        {children}
      </div>
    </div>
  );
};

export default Modal;