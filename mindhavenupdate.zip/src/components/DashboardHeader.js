import React from 'react';

// We pass the user object as a prop to display their name.
const DashboardHeader = ({ user }) => {
  return (
    <header className="flex justify-between items-center mb-8">
      {/* Search Bar */}
      <div className="flex-1">
        <input 
          type="search" 
          placeholder="Search resources, posts, or tools" 
          className="w-full max-w-lg p-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>
      
      {/* Action Buttons */}
      <div className="flex items-center gap-4">
        <button className="bg-slate-200 hover:bg-slate-300 text-slate-800 font-semibold py-2 px-4 rounded-lg">
          Help
        </button>
        <button className="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg">
          New
        </button>
      </div>
    </header>
  );
};

export default DashboardHeader;