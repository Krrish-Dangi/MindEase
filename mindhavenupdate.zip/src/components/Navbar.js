import React from 'react';
import { Link as ScrollLink } from 'react-scroll';
import { Link as RouterLink } from 'react-router-dom';

const Navbar = () => {
  return (
    <header className="bg-white py-4 sticky top-0 z-50 shadow-sm">
      <div className="container mx-auto flex justify-between items-center px-6">
        <RouterLink to="/" className="text-2xl font-bold text-slate-800">MindHaven</RouterLink>
        <nav className="hidden md:flex space-x-8 items-center font-semibold text-slate-600">
          <a href="#" className="hover:text-blue-600 cursor-pointer">Features</a>
          <ScrollLink to="how-it-works-section" smooth duration={500} offset={-50} className="hover:text-blue-600 cursor-pointer">How it works</ScrollLink>
          <a href="#" className="hover:text-blue-600 cursor-pointer">Pricing</a>
        </nav>
        <div className="flex items-center gap-4">
          <RouterLink to="/signin" className="font-bold text-slate-600 hover:text-blue-600">Sign In</RouterLink>
          <RouterLink to="/signup" className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-5 rounded-lg shadow-md">Sign Up</RouterLink>
        </div>
      </div>
    </header>
  );
};
export default Navbar;