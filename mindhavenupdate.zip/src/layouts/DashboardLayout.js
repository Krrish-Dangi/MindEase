import React from 'react';
import { Outlet } from 'react-router-dom';
import Sidebar from '../components/Sidebar';

const DashboardLayout = () => {
  return (
    <div className="flex h-screen bg-gray-50">
      
      {/* The Sidebar is fixed and always present */}
      <Sidebar />

      {/* 
        This is a clever trick to prevent the main content from being
        hidden underneath the fixed sidebar. We add left padding
        equal to the sidebar's width.
      */}
      <div className="flex-1 pl-64"> {/* <-- pl-64 matches the w-64 of the sidebar */}
        <main className="overflow-y-auto p-8 h-full">
          {/* 
            The Outlet is the placeholder from React Router where the actual
            page components (like DashboardHomePage) will be rendered.
          */}
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default DashboardLayout;