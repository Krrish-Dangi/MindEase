import React from 'react';
import BookingSystemPage from './pages/BookingSystemPage';
import AiSupportPage from './pages/AiSupportPage';
import { Routes, Route } from 'react-router-dom';

// Import all public-facing page components
import LandingPage from './pages/LandingPage';
import SignIn from './pages/SignIn'; 
import SignUp from './pages/SignUp';

// Import the layout and pages for the logged-in experience
import DashboardLayout from './layouts/DashboardLayout';
import DashboardHomePage from './pages/DashboardHomePage';

function App() {
  return (
    <Routes>
      {/* --- PUBLIC ROUTES --- */}
      {/* These routes are accessible to everyone before they log in. */}
      <Route path="/" element={<LandingPage />} />
  <Route path="/signin" element={<SignIn />} />
  <Route path="/signup" element={<SignUp />} />
  <Route path="/booking" element={<BookingSystemPage />} />
      
      {/* --- PROTECTED / LOGGED-IN ROUTES --- */}
      {/* This is a nested route group. Any URL that starts with "/app" will
          first render the DashboardLayout component. The DashboardLayout
          contains the sidebar and an <Outlet>. The specific page for the
          URL (like DashboardHomePage) will then be rendered inside that <Outlet>. */}
  <Route path="/app" element={<DashboardLayout />}> 
        
        {/* The 'index' route is the default page shown for the parent path.
            So, when the user navigates to "/app", this is what they will see. */}
        <Route index element={<DashboardHomePage />} />
        
  {/* You can also define the dashboard path explicitly. */}
  <Route path="dashboard" element={<DashboardHomePage />} />
  <Route path="booking-system" element={<BookingSystemPage />} />
  <Route path="ai-support" element={<AiSupportPage />} />
        
        {/*
          =======================================================
          == WHEN YOU BUILD THE OTHER PAGES, YOU WILL ADD THEM HERE ==
          =======================================================
          For example:
          <Route path="ai-support" element={<AiSupportPage />} />
          <Route path="resource-hub" element={<ResourceHubPage />} />
        */}
        
      </Route>
      
    </Routes>
  );
}

export default App;