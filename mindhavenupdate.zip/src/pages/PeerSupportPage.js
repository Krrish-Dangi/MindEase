import React from 'react';
const PeerSupportPage = () => <h1 className="text-3xl font-bold">Peer Support Page (Coming Soon!)</h1>;
export default PeerSupportPage;