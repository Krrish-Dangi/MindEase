// src/pages/DashboardHomePage.js
import React, { useState } from 'react';
import DashboardHeader from '../components/DashboardHeader';
import Modal from '../components/Modal'; 
// 👇 FIX IS HERE: Added FaPlusCircle and FaTimes to the import
import { FaPlus, FaBookOpen, FaPlusCircle, FaTimes } from 'react-icons/fa';

const user = { name: 'Aanya' };

// --- Other placeholder components ---
const ConcentrationCard = () => (
  <div className="bg-white p-6 rounded-lg border border-slate-200 shadow-sm">
    <p className="font-semibold text-sm text-blue-600">Concentration Space</p>
    <h2 className="text-2xl font-bold text-slate-800 my-2">Stay focused, study smarter</h2>
    <p className="text-slate-500 mb-4">Personalized strategies, quick tools, and peers to keep you on track.</p>
    <div className="flex gap-4">
      <button className="bg-blue-600 text-white font-bold py-2 px-4 rounded-lg">Start 5-min Focus</button>
      <button className="bg-slate-100 text-slate-800 font-bold py-2 px-4 rounded-lg">Get AI Prompt</button>
    </div>
  </div>
);
const ToolsCard = () => (<div className="bg-white p-6 rounded-lg border border-slate-200 shadow-sm"><h3 className="font-bold text-slate-800 text-xl mb-4">Tools</h3><div className="space-y-3"><p className="p-3 bg-slate-50 rounded-lg">Concentration Timer</p><p className="p-3 bg-slate-50 rounded-lg">AI Companion Chat</p></div></div>);
const PeerSupportCard = () => (<div className="bg-white p-6 rounded-lg border border-slate-200 shadow-sm"><h3 className="font-bold text-slate-800 text-xl mb-4">Peer Support Groups</h3><div className="space-y-3"><p className="p-3 bg-slate-50 rounded-lg">Join: Exam Anxiety Group</p><p className="p-3 bg-slate-50 rounded-lg">Join: First Year Students</p></div></div>);
const RecommendedResourcesCard = () => (<div className="bg-white p-6 rounded-lg border border-slate-200 shadow-sm"><h3 className="font-bold text-slate-800 text-xl mb-4">Recommended resources</h3><div className="space-y-3"><p className="p-3 bg-slate-50 rounded-lg">Guide: Deep work for busy weeks</p><p className="p-3 bg-slate-50 rounded-lg">3-minute video: Reset your attention</p></div></div>);
// --- End of placeholder components ---


const StudyPlanCard = () => { 
  const [plans, setPlans] = useState([
    { id: 1, title: 'Review lecture notes for PSYCH 101', description: 'Focus on chapters 4 and 5. Create flashcards for key terms.' },
    { id: 2, title: 'Complete Chapter 3 of calculus homework', description: 'Problems 1-15. Pay attention to the examples on integration.' },
  ]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentPlan, setCurrentPlan] = useState(null); 
  const [modalMode, setModalMode] = useState('add');

  const handleOpenModal = (mode, plan = null) => {
    setModalMode(mode);
    if (mode === 'edit' && plan) {
      setCurrentPlan(plan);
    } else {
      setCurrentPlan({ title: '', description: '' });
    }
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setCurrentPlan(null);
  };
  
  const handleSavePlan = () => {
    if (!currentPlan.title.trim()) {
      alert("Title cannot be empty!");
      return;
    }
    if (modalMode === 'add') {
      setPlans([...plans, { ...currentPlan, id: Date.now() }]);
    } else {
      setPlans(plans.map(p => p.id === currentPlan.id ? currentPlan : p));
    }
    handleCloseModal();
  };

  const handlePlanChange = (e) => {
    const { name, value } = e.target;
    setCurrentPlan({ ...currentPlan, [name]: value });
  };

  return (
    <>
      <div className="bg-blue-50 p-6 rounded-lg border border-blue-200 flex flex-col h-full">
        <h3 className="text-slate-600 font-bold text-xl mb-4">Your Study Plan</h3>
        <div className="flex-grow space-y-2 overflow-y-auto">
          {plans.map((plan) => (
            <div key={plan.id} onClick={() => handleOpenModal('edit', plan)} className="flex items-center bg-white p-3 rounded-lg cursor-pointer hover:bg-slate-100">
              <FaBookOpen className="text-blue-500 mr-3" />
              <p className="text-slate-700 text-sm font-semibold">{plan.title}</p>
            </div>
          ))}
          <div onClick={() => handleOpenModal('add')} className="flex items-center justify-center bg-white p-3 rounded-lg cursor-pointer hover:bg-slate-100 border-2 border-dashed border-slate-300">
            <FaPlus className="text-slate-400" />
          </div>
        </div>
      </div>
      <Modal isOpen={isModalOpen} onClose={handleCloseModal}>
        {currentPlan && (
          <>
            <h2 className="text-2xl font-bold mb-4">{modalMode === 'add' ? 'Add New Plan' : 'Edit Study Plan'}</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-1">Title</label>
                <input type="text" name="title" value={currentPlan.title} onChange={handlePlanChange} className="w-full p-2 border border-slate-300 rounded-lg" />
              </div>
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-1">Description (optional)</label>
                <textarea name="description" value={currentPlan.description} onChange={handlePlanChange} rows="4" className="w-full p-2 border border-slate-300 rounded-lg"></textarea>
              </div>
            </div>
            <div className="mt-6 flex justify-end gap-3">
              <button onClick={handleCloseModal} className="font-semibold py-2 px-4 rounded-lg bg-slate-200 hover:bg-slate-300">Cancel</button>
              <button onClick={handleSavePlan} className="font-semibold py-2 px-4 rounded-lg bg-blue-600 text-white hover:bg-blue-700">Save</button>
            </div>
          </>
        )}
      </Modal>
    </>
  );
};


const QuickStrategiesCard = () => {
  const strategies = [
    { id: 1, title: 'Practice: Box Breathing', tutorial: ['Find a comfortable, quiet place to sit.', 'Inhale slowly through your nose for a count of 4.', 'Hold your breath for a count of 4.', 'Exhale slowly through your mouth for a count of 4.', 'Hold your breath again for a count of 4.', 'Repeat for 2-3 minutes until you feel calm.',], },
    { id: 2, title: 'Read: Overcoming procrastination', tutorial: ['Break your task into smaller, manageable steps.', 'Set a timer for just 15-25 minutes (a "Pomodoro").', 'Work on a single small step until the timer rings.', 'Take a 5-minute break.', 'Repeat the process. The goal is to build momentum.',], },
  ];

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedStrategy, setSelectedStrategy] = useState(null);

  const handleOpenModal = (strategy) => {
    setSelectedStrategy(strategy);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedStrategy(null);
  };

  return (
    <>
      <div className="bg-white p-6 rounded-lg border border-slate-200 shadow-sm">
        <h3 className="font-bold text-slate-800 text-xl mb-4">Quick Strategies</h3>
        <div className="space-y-3">
          {strategies.map((strategy) => (
            <div key={strategy.id} onClick={() => handleOpenModal(strategy)} className="p-3 bg-slate-50 rounded-lg cursor-pointer hover:bg-slate-200 transition">
              {strategy.title}
            </div>
          ))}
        </div>
      </div>
      <Modal isOpen={isModalOpen} onClose={handleCloseModal}>
        {selectedStrategy && (
          <div>
            <h2 className="text-2xl font-bold mb-4">{selectedStrategy.title}</h2>
            <ol className="list-decimal list-inside space-y-3 text-slate-600">
              {selectedStrategy.tutorial.map((step, index) => (<li key={index}>{step}</li>))}
            </ol>
            <div className="mt-6 flex justify-end">
              <button onClick={handleCloseModal} className="font-semibold py-2 px-4 rounded-lg bg-blue-600 text-white hover:bg-blue-700">Got it!</button>
            </div>
          </div>
        )}
      </Modal>
    </>
  );
};

const DashboardHomePage = () => {
  return (
    <div>
      <DashboardHeader user={user} />
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2"><ConcentrationCard /></div>
        <div className="row-span-2"><StudyPlanCard /></div>
        <div className="lg:col-span-2"><QuickStrategiesCard /></div>
        <div><PeerSupportCard /></div>
        <div className="lg:col-span-2"><RecommendedResourcesCard /></div>
        <div><ToolsCard /></div>
      </div>
    </div>
  );
};

export default DashboardHomePage;