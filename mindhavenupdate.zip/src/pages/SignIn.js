import React, { useState } from 'react';
import { FcGoogle } from 'react-icons/fc';
import { FaTwitter, FaEye, FaEyeSlash } from 'react-icons/fa';
import { Link, useNavigate } from 'react-router-dom'; // 1. Import useNavigate

const SignIn = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false); 
  
  const navigate = useNavigate(); // 2. Initialize the navigate function

  const handleSignIn = (event) => {
    event.preventDefault();
    console.log("Simulating sign-in for:", { email, password });
    
    // 3. Navigate to the dashboard after the "login"
    alert('Sign in successful! Redirecting to dashboard...');
    navigate('/app/dashboard'); 
  };

  return (
    <div className="min-h-screen bg-slate-100 flex items-center justify-center p-4">
      {/* ... the rest of your form JSX is unchanged ... */}
      <div className="bg-white rounded-2xl shadow-xl p-8 max-w-md w-full">
        <h1 className="text-3xl font-bold text-center text-slate-800 mb-2">Welcome Back!</h1>
        <p className="text-center text-slate-500 mb-8">Sign in to continue to MindHaven</p>
        <form onSubmit={handleSignIn}>
          <div className="mb-4">
            <label className="block text-slate-700 font-semibold mb-2" htmlFor="email">Email Address</label>
            <input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg" required />
          </div>
          <div className="mb-6 relative">
            <label className="block text-slate-700 font-semibold mb-2" htmlFor="password">Password</label>
            <input id="password" type={showPassword ? 'text' : 'password'} value={password} onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-2 border border-slate-300 rounded-lg" required />
            <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute inset-y-0 right-0 px-3 flex items-center text-slate-500 hover:text-slate-700">{showPassword ? <FaEyeSlash /> : <FaEye />}</button>
          </div>
          <button type="submit" className="w-full bg-blue-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-blue-700">Sign In</button>
        </form>
        <div className="my-8 flex items-center">
          <hr className="flex-grow border-slate-300"/><span className="px-4 text-slate-500 font-semibold">OR</span><hr className="flex-grow border-slate-300"/>
        </div>
        <div className="space-y-4">
          <button className="w-full flex items-center justify-center gap-3 py-3 border border-slate-300 rounded-lg hover:bg-slate-50"><FcGoogle size={24} /><span className="font-bold text-slate-700">Continue with Google</span></button>
          <button className="w-full flex items-center justify-center gap-3 py-3 border border-slate-300 rounded-lg hover:bg-slate-50"><FaTwitter size={24} className="text-sky-500" /><span className="font-bold text-slate-700">Continue with Twitter</span></button>
        </div>
        <p className="text-center text-sm text-slate-500 mt-8">Don't have an account? <Link to="/signup" className="font-bold text-blue-600 hover:underline">Sign up</Link></p>
      </div>
    </div>
  );
};

export default SignIn;