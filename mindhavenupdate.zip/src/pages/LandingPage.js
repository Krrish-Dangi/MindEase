// src/pages/LandingPage.js
import React from 'react';
import Navbar from '../components/Navbar';
import Hero from '../components/Hero';
import WhyMindHaven from '../components/WhyMindHaven';
import HowItWorks from '../components/HowItWorks';
import Footer from '../components/Footer';

const LandingPage = () => {
  return (
    <div className="bg-gray-50 font-sans">
      <Navbar />
      <main>
        <Hero />
        <WhyMindHaven />
        <HowItWorks />
      </main>
      <Footer />
    </div>
  );
};
export default LandingPage;