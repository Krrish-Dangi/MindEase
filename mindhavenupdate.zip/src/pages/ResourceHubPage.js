import React from 'react';
const ResourceHubPage = () => <h1 className="text-3xl font-bold">Resource Hub Page (Coming Soon!)</h1>;
export default ResourceHubPage;