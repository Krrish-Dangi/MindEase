// src/pages/FocusPage.js
import React, { useState, useEffect } from 'react';
import { FaPlay, FaPause, FaRedo, FaCog } from 'react-icons/fa';
import { Link } from 'react-router-dom';

const FocusPage = () => {
  const [minutes, setMinutes] = useState(25);
  const [seconds, setSeconds] = useState(0);
  const [isActive, setIsActive] = useState(false);
  const [task, setTask] = useState('');

  useEffect(() => {
    let interval = null;
    if (isActive) {
      interval = setInterval(() => {
        if (seconds === 0) {
          if (minutes === 0) {
            alert(`Session complete for: ${task || 'your task'}!`);
            resetTimer();
          } else {
            setMinutes(minutes - 1);
            setSeconds(59);
          }
        } else {
          setSeconds(seconds - 1);
        }
      }, 1000);
    } else {
      clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, [isActive, seconds, minutes, task]);

  const toggleTimer = () => {
    if (task.trim() === '') {
      alert('Please enter a task to focus on.');
      return;
    }
    setIsActive(!isActive);
  };

  const resetTimer = () => {
    setIsActive(false);
    setMinutes(25);
    setSeconds(0);
  };
  
  const totalSeconds = 25 * 60;
  const remainingSeconds = minutes * 60 + seconds;
  const progress = ((totalSeconds - remainingSeconds) / totalSeconds) * 100;

  return (
    <div className="flex flex-col items-center justify-center h-full bg-slate-50 p-4">
      <div className="w-full max-w-2xl bg-white p-8 rounded-2xl shadow-lg border border-slate-200 text-center">
        
        <div className="w-full flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-slate-800">Concentration Timer</h2>
          <div className="flex items-center gap-4">
            <button className="text-slate-400 hover:text-slate-600"><FaCog size={20} /></button>
            <Link to="/app/dashboard" className="text-sm font-semibold text-blue-600 hover:underline">Back to Dashboard</Link>
          </div>
        </div>

        <div className="relative w-64 h-64 mx-auto mb-6">
          <svg className="w-full h-full" viewBox="0 0 100 100">
            <circle className="text-slate-200" strokeWidth="10" stroke="currentColor" fill="transparent" r="45" cx="50" cy="50" />
            <circle
              className="text-blue-600 transition-all duration-500"
              strokeWidth="10"
              strokeDasharray="283"
              strokeDashoffset={283 - (progress / 100) * 283}
              strokeLinecap="round"
              stroke="currentColor"
              fill="transparent"
              r="45"
              cx="50"
              cy="50"
              style={{ transform: 'rotate(-90deg)', transformOrigin: '50% 50%' }}
            />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-6xl font-bold text-slate-800">
              {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
            </span>
          </div>
        </div>

        <div className="w-full max-w-sm mx-auto mb-6">
          <label htmlFor="task" className="block text-center text-sm font-semibold text-slate-500 mb-2">Focusing on</label>
          <input
            type="text"
            id="task"
            value={task}
            onChange={(e) => setTask(e.target.value)}
            placeholder="E.g., Finish chemistry homework"
            className="w-full text-center text-lg px-4 py-2 border-b-2 border-slate-300 focus:border-blue-500 outline-none"
          />
        </div>
        
        <div className="flex items-center justify-center gap-4">
          <button onClick={resetTimer} className="p-4 rounded-full bg-slate-200 text-slate-600 hover:bg-slate-300">
            <FaRedo />
          </button>
          <button onClick={toggleTimer} className="px-10 py-4 rounded-full bg-blue-600 text-white font-bold text-lg hover:bg-blue-700 flex items-center gap-2">
            {isActive ? <><FaPause /> Pause</> : <><FaPlay /> Start</>}
          </button>
        </div>
      </div>
    </div>
  );
};

export default FocusPage;