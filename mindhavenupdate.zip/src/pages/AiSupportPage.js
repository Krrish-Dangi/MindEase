import React, { useState } from 'react';
import { FaMicrophone, FaPaperclip, FaPaperPlane, FaChevronDown, FaChevronUp } from 'react-icons/fa';
import { HiOutlineHeart } from 'react-icons/hi';

const quickActions = [
	"I'm feeling stressed",
	'Help me with study planning',
	'I need financial aid guidance',
	'Talk to a peer supporter',
];

const emotions = [
	{ icon: '🙂', label: 'Okay' },
	{ icon: '😊', label: 'Happy' },
	{ icon: '😟', label: 'Worried' },
	{ icon: '😢', label: 'Sad' },
	{ icon: '😡', label: 'Angry' },
];

const resources = [
	{ title: 'Campus Resources', link: '#' },
	{ title: 'Self-care Exercises', link: '#' },
	{ title: 'Meditation Audio', link: '#' },
	{ title: 'Emergency Helplines', link: '#' },
];

const initialMessages = [
	{ sender: 'ai', text: 'Hi Aanya! How can I support you today?' },
	{ sender: 'user', text: 'I am feeling stressed about exams.' },
	{ sender: 'ai', text: 'I understand. Would you like some tips for managing exam stress or talk to a peer supporter?' },
];

function TypingIndicator() {
	return (
		<div className="flex items-center space-x-1 ml-12 mb-2">
			<span className="block w-2 h-2 bg-blue-300 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></span>
			<span className="block w-2 h-2 bg-blue-300 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></span>
			<span className="block w-2 h-2 bg-blue-300 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></span>
		</div>
	);
}

const AiSupportPage = () => {
	const [messages, setMessages] = useState(initialMessages);
	const [input, setInput] = useState('');
	const [selectedEmotion, setSelectedEmotion] = useState(0);
	const [showResources, setShowResources] = useState(true);

	const handleSend = () => {
		if (!input.trim()) return;
		setMessages([...messages, { sender: 'user', text: input }]);
		setInput('');
		// Simulate AI response
		setTimeout(() => {
			setMessages(msgs => [...msgs, { sender: 'ai', text: 'Thank you for sharing. Here are some resources that might help.' }]);
		}, 1200);
	};

	return (
		<div className="min-h-screen bg-gray-50 flex">
			{/* Sidebar is handled by DashboardLayout */}
			<div className="flex-1 flex flex-col items-center justify-start py-10 px-4 md:px-12 lg:px-24">
				{/* Header Row */}
				<div className="w-full max-w-3xl flex items-center justify-between mb-6">
					<div>
						<h1 className="text-2xl md:text-3xl font-semibold text-gray-800">AI Support Assistant</h1>
						<p className="text-sm text-gray-500 mt-1">Confidential • Student-first • Available 24/7</p>
					</div>
					<div className="flex space-x-2">
						<button className="px-4 py-2 rounded-full border border-blue-200 text-blue-700 bg-white font-medium text-xs flex items-center">Privacy & Consent</button>
						<button className="px-4 py-2 rounded-full border border-blue-200 text-blue-700 bg-white font-medium text-xs flex items-center">Emergency Contacts</button>
					</div>
				</div>

				{/* Main Chat Card */}
				<div className="w-full max-w-3xl flex gap-6">
					{/* Chat Section */}
					<div className="flex-1">
						{/* AI Tone Badge */}
						<div className="mb-2">
							<span className="inline-block px-3 py-1 rounded-full bg-blue-50 text-xs text-blue-700 font-medium">Compassionate mode · Confidential</span>
						</div>
						{/* Quick Actions */}
						<div className="flex space-x-3 overflow-x-auto pb-2 mb-4 hide-scrollbar">
							{quickActions.map((action, i) => (
								<button key={action} className="flex-shrink-0 px-4 py-2 rounded-full bg-blue-50 text-blue-700 font-medium shadow hover:shadow-lg transition-all text-sm border border-blue-100">{action}</button>
							))}
						</div>
						{/* Chat Bubbles */}
						<div className="bg-white rounded-2xl shadow p-6 mb-2" style={{ minHeight: 340 }}>
							{messages.map((msg, i) => (
								msg.sender === 'ai' ? (
									<div key={i} className="flex items-start mb-4">
										<div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center mr-3">
											<HiOutlineHeart className="text-blue-500 text-2xl" />
										</div>
										<div>
											<div className="bg-blue-50 rounded-2xl px-4 py-2 text-gray-800 text-sm shadow-sm max-w-md">{msg.text}</div>
										</div>
									</div>
								) : (
									<div key={i} className="flex items-end justify-end mb-4">
										<div>
											<div className="bg-white border border-blue-200 rounded-2xl px-4 py-2 text-gray-800 text-sm shadow-sm max-w-md">{msg.text}</div>
										</div>
									</div>
								)
							))}
							{/* Typing indicator example */}
							<TypingIndicator />
						</div>
						{/* Emotion Selector */}
						<div className="flex items-center space-x-2 mb-4">
							{emotions.map((e, i) => (
								<button
									key={e.label}
									className={`w-9 h-9 flex items-center justify-center rounded-full text-xl border transition-all ${selectedEmotion === i ? 'bg-blue-100 border-blue-500 shadow' : 'bg-white border-gray-200'} hover:shadow-lg`}
									onClick={() => setSelectedEmotion(i)}
									aria-label={e.label}
								>{e.icon}</button>
							))}
						</div>
									{/* Input Bar */}
									<div className="flex items-center mt-2 bg-white rounded-full border-2 border-blue-200 px-4 py-2 shadow focus-within:border-blue-500">
										<input
											className="flex-1 bg-transparent outline-none text-gray-700 text-sm px-2"
											type="text"
											placeholder="Ask me anything…"
											value={input}
											onChange={e => setInput(e.target.value)}
											onKeyDown={e => e.key === 'Enter' && handleSend()}
										/>
										{/* Speech/Mic Icon */}
										<button className="mx-2 text-blue-500 hover:text-blue-700" title="Talk to Speech">
											<FaMicrophone />
										</button>
										<button className="mx-2 text-blue-500 hover:text-blue-700"><FaPaperclip /></button>
										<button className="ml-2 px-3 py-1 rounded-full bg-blue-600 text-white font-semibold text-sm hover:bg-blue-700" onClick={handleSend}><FaPaperPlane /></button>
									</div>
						{/* Footer Disclaimer */}
						<div className="mt-6 text-xs text-gray-400 text-center">
							This AI assistant is supportive but not a substitute for professional help. In crisis, please use emergency contacts.
						</div>
					</div>
					{/* Resource Suggestions Panel */}
					<div className="w-80 hidden lg:block">
						<div className="bg-white rounded-2xl shadow p-4 mb-2 flex items-center justify-between cursor-pointer" onClick={() => setShowResources(!showResources)}>
							<span className="font-semibold text-gray-700">Recommended Resources</span>
							{showResources ? <FaChevronUp className="text-gray-400" /> : <FaChevronDown className="text-gray-400" />}
						</div>
						{showResources && (
							<div className="bg-white rounded-2xl shadow p-4">
								<ul className="space-y-3">
									{resources.map(r => (
										<li key={r.title}>
											<a href={r.link} className="block px-3 py-2 rounded-lg bg-blue-50 text-blue-700 font-medium hover:bg-blue-100 transition-all text-sm">{r.title}</a>
										</li>
									))}
								</ul>
							</div>
						)}
					</div>
				</div>
			</div>
		</div>
	);
};

export default AiSupportPage;