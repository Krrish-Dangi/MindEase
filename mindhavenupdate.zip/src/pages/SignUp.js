import React, { useState } from 'react';
import { FaEye, FaEyeSlash, FaTwitter } from 'react-icons/fa';
import { FcGoogle } from 'react-icons/fc';
import { Link, useNavigate } from 'react-router-dom'; // 1. Import useNavigate

const SignUp = () => {
  // ... (all your existing useState declarations are unchanged) ...
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [role, setRole] = useState('student');
  const [dob, setDob] = useState('');
  const [gender, setGender] = useState('');
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const navigate = useNavigate(); // 2. Initialize the navigate function

  const handleSignUp = (event) => {
    event.preventDefault();
    if (password !== confirmPassword) {
      alert("Passwords do not match!");
      return;
    }
    if (!agreedToTerms) {
      alert("You must agree to the Terms of Service and Privacy Policy.");
      return;
    }
    
    console.log("Creating account:", { fullName, email, password, role, dob, gender });
    
    // 3. Navigate to the dashboard after the "sign up"
    alert('Sign up successful! Redirecting to dashboard...');
    navigate('/app/dashboard');
  };

  return (
    <div className="min-h-screen bg-slate-100 flex items-center justify-center py-12 px-4">
      {/* ... the rest of your form JSX is unchanged ... */}
      <div className="bg-white rounded-2xl shadow-xl p-8 max-w-lg w-full">
        <h1 className="text-3xl font-bold text-center text-slate-800 mb-2">Create Your Account</h1>
        <p className="text-center text-slate-500 mb-8">Join MindHaven for tailored wellness support.</p>
        <div className="space-y-4 mb-6">
           <button className="w-full flex items-center justify-center gap-3 py-3 border border-slate-300 rounded-lg hover:bg-slate-50"><FcGoogle size={24} /><span className="font-bold text-slate-700">Sign up with Google</span></button>
           <button className="w-full flex items-center justify-center gap-3 py-3 border border-slate-300 rounded-lg hover:bg-slate-50"><FaTwitter size={24} className="text-sky-500" /><span className="font-bold text-slate-700">Sign up with X</span></button>
        </div>
        <div className="my-6 flex items-center">
          <hr className="flex-grow border-slate-300"/><span className="px-4 text-slate-500 font-semibold text-sm">OR SIGN UP WITH EMAIL</span><hr className="flex-grow border-slate-300"/>
        </div>
        <form onSubmit={handleSignUp} className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div><label className="block text-slate-700 font-semibold mb-2" htmlFor="fullName">Full Name</label><input id="fullName" type="text" value={fullName} onChange={(e) => setFullName(e.target.value)} className="w-full px-4 py-2 border border-slate-300 rounded-lg" required /></div>
            <div><label className="block text-slate-700 font-semibold mb-2" htmlFor="email">Email Address</label><input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="w-full px-4 py-2 border border-slate-300 rounded-lg" required /></div>
            <div><label className="block text-slate-700 font-semibold mb-2" htmlFor="dob">Date of Birth</label><input id="dob" type="date" value={dob} onChange={(e) => setDob(e.target.value)} className="w-full px-4 py-2 border border-slate-300 rounded-lg" required /></div>
            <div><label className="block text-slate-700 font-semibold mb-2" htmlFor="gender">Gender (Optional)</label><select id="gender" value={gender} onChange={(e) => setGender(e.target.value)} className="w-full px-4 py-2 border border-slate-300 rounded-lg bg-white"><option value="">Prefer not to say</option><option value="female">Female</option><option value="male">Male</option><option value="other">Other</option></select></div>
            <div className="md:col-span-2"><label className="block text-slate-700 font-semibold mb-2" htmlFor="role">Your Role</label><select id="role" value={role} onChange={(e) => setRole(e.target.value)} className="w-full px-4 py-2 border border-slate-300 rounded-lg bg-white"><option value="student">Student</option><option value="faculty">Faculty / Staff</option><option value="counselor">Counselor</option></select></div>
            <div className="relative"><label className="block text-slate-700 font-semibold mb-2" htmlFor="password">Password</label><input id="password" type={showPassword ? 'text' : 'password'} value={password} onChange={(e) => setPassword(e.target.value)} className="w-full px-4 py-2 border border-slate-300 rounded-lg" required /><button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute inset-y-0 right-0 top-7 px-3 flex items-center text-slate-500">{showPassword ? <FaEyeSlash /> : <FaEye />}</button></div>
            <div className="relative"><label className="block text-slate-700 font-semibold mb-2" htmlFor="confirmPassword">Confirm Password</label><input id="confirmPassword" type={showConfirmPassword ? 'text' : 'password'} value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} className="w-full px-4 py-2 border border-slate-300 rounded-lg" required /><button type="button" onClick={() => setShowConfirmPassword(!showConfirmPassword)} className="absolute inset-y-0 right-0 top-7 px-3 flex items-center text-slate-500">{showConfirmPassword ? <FaEyeSlash /> : <FaEye />}</button></div>
          </div>
          <div className="flex items-start pt-2"><input id="terms" type="checkbox" checked={agreedToTerms} onChange={(e) => setAgreedToTerms(e.target.checked)} className="h-4 w-4 text-blue-600 rounded mt-1" /><label htmlFor="terms" className="ml-2 block text-sm text-slate-600">I agree to the <Link to="/terms" className="font-bold hover:underline">Terms of Service</Link> and <Link to="/privacy" className="font-bold hover:underline">Privacy Policy</Link>.</label></div>
          <button type="submit" disabled={!agreedToTerms} className="w-full bg-blue-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-blue-700 disabled:bg-blue-400 disabled:cursor-not-allowed">Create Account</button>
        </form>
        <p className="text-center text-sm text-slate-500 mt-6">Already have an account? <Link to="/signin" className="font-bold text-blue-600 hover:underline">Sign in</Link></p>
      </div>
    </div>
  );
};
export default SignUp;