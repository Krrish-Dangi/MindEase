import React, { useState } from 'react';

const services = [
  { name: 'Counseling session', duration: '45 min', desc: 'One-on-one • On-campus or virtual' },
  { name: 'Peer support', duration: '30 min', desc: 'Student-to-student • Confidential' },
  { name: 'Financial counseling', duration: '30 min', desc: 'Aid, budgeting, emergency grants' },
];

const providers = [
  { name: 'Dr. Maya Patel', role: 'Counselor • On-campus & Virtual', focus: 'Anxiety', rating: 4.8, img: 'https://randomuser.me/api/portraits/women/44.jpg' },
  { name: 'Alex Johnson', role: 'Peer supporter • Evenings', focus: 'Study stress', rating: 4.7, img: 'https://randomuser.me/api/portraits/men/32.jpg' },
  { name: 'Linh Nguyen', role: 'Financial advisor • Virtual', focus: 'Grants', rating: 4.6, img: 'https://randomuser.me/api/portraits/women/65.jpg' },
  { name: 'Sara Kim', role: 'Counselor • Virtual first', focus: 'Burnout', rating: 4.9, img: 'https://randomuser.me/api/portraits/women/68.jpg' },
];

const times = ['09:00', '10:30', '13:00', '14:30', '16:00', '17:30'];
const days = ['Mon 10', 'Tue 11', 'Wed 12', 'Thu 13', 'Fri 14', 'Sat 15', 'Sun 16'];

const BookingSystemPage = () => {
  const [selectedService, setSelectedService] = useState(0);
  const [selectedDay, setSelectedDay] = useState(2);
  const [selectedTime, setSelectedTime] = useState('10:30');
  const [selectedProvider, setSelectedProvider] = useState(0);

  return (
    <div className="min-h-screen bg-gray-50 px-8 py-6">
      <h1 className="text-3xl font-bold mb-6 text-gray-900">Booking System</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
        {/* Service selection */}
        <div className="bg-white rounded-xl shadow p-6">
          <h2 className="text-lg font-semibold mb-4">Choose service</h2>
          <div className="space-y-3 mb-6">
            {services.map((s, i) => (
              <button
                key={s.name}
                className={`w-full flex items-center justify-between p-4 rounded-lg border ${selectedService === i ? 'border-blue-600 bg-blue-50' : 'border-gray-200 bg-white'} transition`}
                onClick={() => setSelectedService(i)}
              >
                <div>
                  <div className="font-medium text-gray-900">{s.name}</div>
                  <div className="text-sm text-gray-500">{s.desc}</div>
                </div>
                <span className="ml-4 px-2 py-1 bg-gray-100 rounded text-xs font-semibold">{s.duration}</span>
              </button>
            ))}
          </div>
          <div className="mb-4">
            <h3 className="font-semibold text-gray-700 mb-2">Preferences</h3>
            <div className="space-y-2">
              <button className="w-full flex items-center justify-between p-2 rounded border border-gray-200 text-gray-700">Location: On-campus</button>
              <button className="w-full flex items-center justify-between p-2 rounded border border-gray-200 text-gray-700">Format: Virtual</button>
              <button className="w-full flex items-center justify-between p-2 rounded border border-gray-200 text-gray-700">Preference: First available</button>
            </div>
          </div>
          <div>
            <h3 className="font-semibold text-gray-700 mb-2">Accessibility</h3>
            <div className="space-y-2">
              <button className="w-full flex items-center justify-between p-2 rounded border border-gray-200 text-gray-700">Accessibility needs</button>
              <button className="w-full flex items-center justify-between p-2 rounded border border-gray-200 text-gray-700">Language options</button>
            </div>
          </div>
        </div>

        {/* Date, time, provider selection */}
        <div className="bg-white rounded-xl shadow p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">November 2025</h2>
            <span className="text-sm text-gray-500">Week view • Campus TZ</span>
          </div>
          <div className="flex space-x-2 mb-4">
            {days.map((d, i) => (
              <button
                key={d}
                className={`px-3 py-2 rounded-lg border ${selectedDay === i ? 'border-blue-600 bg-blue-50' : 'border-gray-200 bg-white'} text-sm font-medium`}
                onClick={() => setSelectedDay(i)}
              >{d}</button>
            ))}
          </div>
          <div className="grid grid-cols-3 gap-2 mb-6">
            {times.map(t => (
              <button
                key={t}
                className={`py-2 rounded-lg border ${selectedTime === t ? 'border-blue-600 bg-blue-50' : 'border-gray-200 bg-white'} text-sm font-medium`}
                onClick={() => setSelectedTime(t)}
              >{t}</button>
            ))}
          </div>
          <div className="mb-4">
            <h3 className="font-semibold text-gray-700 mb-2">Available providers <span className="text-xs text-gray-400">Showing 4</span></h3>
            <div className="grid grid-cols-2 gap-3">
              {providers.map((p, i) => (
                <button
                  key={p.name}
                  className={`flex items-center p-3 rounded-lg border w-full ${selectedProvider === i ? 'border-blue-600 bg-blue-50' : 'border-gray-200 bg-white'} transition`}
                  onClick={() => setSelectedProvider(i)}
                >
                  <img src={p.img} alt={p.name} className="w-10 h-10 rounded-full mr-3 object-cover" />
                  <div className="flex-1 text-left">
                    <div className="font-medium text-gray-900">{p.name}</div>
                    <div className="text-xs text-gray-500">{p.role}</div>
                    <span className="inline-block mt-1 px-2 py-0.5 bg-gray-100 rounded text-xs font-semibold">Focus: {p.focus}</span>
                  </div>
                  <span className="ml-2 text-xs text-gray-500">{p.rating}</span>
                </button>
              ))}
            </div>
          </div>
          <div className="flex items-center space-x-2 mt-2">
            <button className="px-4 py-2 rounded border border-gray-300 text-gray-600 bg-white">Clear</button>
            <button className="px-4 py-2 rounded bg-blue-600 text-white font-semibold hover:bg-blue-700">Confirm booking</button>
          </div>
        </div>
      </div>

      {/* Upcoming bookings */}
      <div className="bg-white rounded-xl shadow p-6 mb-4">
        <h2 className="text-lg font-semibold mb-4">Your upcoming</h2>
        <div className="flex flex-wrap gap-4">
          <div className="bg-blue-50 rounded-lg px-4 py-2 flex flex-col items-start">
            <span className="font-medium text-blue-700">Counseling</span>
            <span className="text-xs text-gray-500">Wed 12 • 10:30</span>
            <span className="text-xs text-gray-500">Virtual • Dr. Maya Patel</span>
          </div>
          <div className="bg-blue-50 rounded-lg px-4 py-2 flex flex-col items-start">
            <span className="font-medium text-blue-700">Peer support</span>
            <span className="text-xs text-gray-500">Fri 14 • 16:00</span>
            <span className="text-xs text-gray-500">On-campus • Alex Johnson</span>
          </div>
          <div className="bg-blue-50 rounded-lg px-4 py-2 flex flex-col items-start">
            <span className="font-medium text-blue-700">Financial counseling</span>
            <span className="text-xs text-gray-500">Mon 17 • 09:00</span>
            <span className="text-xs text-gray-500">Virtual • Linh Nguyen</span>
          </div>
        </div>
        <button className="mt-4 px-3 py-1 rounded border border-gray-300 text-gray-600 bg-white">Manage</button>
      </div>

      {/* Footer */}
      <div className="flex justify-between items-center text-xs text-gray-400 mt-8">
        <div className="space-x-4">
          <a href="#" className="hover:underline">Privacy</a>
          <a href="#" className="hover:underline">Terms</a>
          <a href="#" className="hover:underline">Support</a>
        </div>
        <div>Appointments are confidential. In crisis, use emergency contacts.</div>
      </div>
    </div>
  );
};

export default BookingSystemPage;
