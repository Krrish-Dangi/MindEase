import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';

// Step 1: Import BrowserRouter from the react-router-dom library
import { BrowserRouter } from 'react-router-dom';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    {/*
      Step 2: Wrap the main <App /> component with <BrowserRouter>.
      This "activates" routing and makes it available to all other
      components inside your application.
    */}
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </React.StrictMode>
);