
  # MindEase Landing Updated

  This is a code bundle for MindEase Landing Updated. The original project is available at https://www.figma.com/design/zLJtD58FWEfBluyoskhtez/MindEase-Landing-Updated.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  