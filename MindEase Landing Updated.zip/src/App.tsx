import { useState, useEffect } from "react";
import { Header } from "./components/header";
import { HeroSection } from "./components/hero-section";
import { FeaturesSection } from "./components/features-section";
import { TrustSection } from "./components/trust-section";
import { WhyMindEaseSection } from "./components/why-mindease-section";
import { TestimonialSection } from "./components/testimonial-section";
import { Footer } from "./components/footer";
import { SplashScreen } from "./components/splash-screen";
import { DashboardLayout } from "./components/dashboard-layout";
import { DashboardHome } from "./components/dashboard-home";
import { BookingSystem } from "./components/booking-system";
import { SettingsPage } from "./components/settings-page";
import { LanguageProvider } from "./contexts/language-context";
import { AuthProvider, useAuth } from "./contexts/auth-context";

function AppContent() {
  const { isAuthenticated } = useAuth();
  const [showSplash, setShowSplash] = useState(!isAuthenticated);
  const [currentPage, setCurrentPage] = useState('dashboard');

  // Set dark mode as default
  useEffect(() => {
    document.documentElement.classList.add('dark');
  }, []);

  if (showSplash && !isAuthenticated) {
    return <SplashScreen onComplete={() => setShowSplash(false)} />;
  }

  const renderDashboardContent = () => {
    switch (currentPage) {
      case 'dashboard':
        return <DashboardHome />;
      case 'booking':
        return <BookingSystem />;
      case 'settings':
        return <SettingsPage />;
      case 'ai':
        return (
          <div className="flex items-center justify-center min-h-96 relative mindease-subtle-stars">
            <div className="text-center border p-12 rounded-3xl shadow-2xl backdrop-blur-xl relative z-10 max-w-md" style={{
              background: 'linear-gradient(135deg, rgba(147, 197, 253, 0.15) 0%, rgba(59, 130, 246, 0.12) 50%, rgba(37, 99, 235, 0.08) 100%)',
              borderColor: 'rgba(147, 197, 253, 0.4)',
              boxShadow: '0 20px 40px rgba(59, 130, 246, 0.2), 0 0 80px rgba(147, 197, 253, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.1)'
            }}>
              {/* Animated particles */}
              <div className="absolute -top-2 -right-2 w-16 h-16 rounded-full opacity-20 animate-pulse" style={{
                background: 'radial-gradient(circle, rgba(147, 197, 253, 0.8) 0%, transparent 70%)'
              }}></div>
              
              <div className="w-20 h-20 rounded-3xl mx-auto mb-6 flex items-center justify-center shadow-lg" 
                   style={{ background: 'linear-gradient(135deg, rgba(147, 197, 253, 0.8) 0%, rgba(59, 130, 246, 0.9) 50%, rgba(37, 99, 235, 0.8) 100%)' }}>
                <span className="text-3xl">🤖</span>
              </div>
              <h2 className="text-3xl font-semibold text-white mb-4">AI Support Chat</h2>
              <p className="text-gray-300 mb-6 leading-relaxed">Intelligent mental health support available 24/7</p>
              <div className="inline-flex items-center space-x-2 text-yellow-400">
                <span className="animate-pulse">✧</span>
                <span className="text-sm">Coming soon...</span>
                <span className="animate-pulse">✧</span>
              </div>
            </div>
          </div>
        );
      case 'p2p':
        return (
          <div className="flex items-center justify-center min-h-96 relative mindease-subtle-stars">
            <div className="text-center border p-12 rounded-3xl shadow-2xl backdrop-blur-xl relative z-10 max-w-md" style={{
              background: 'linear-gradient(135deg, rgba(196, 181, 253, 0.15) 0%, rgba(139, 92, 246, 0.12) 50%, rgba(109, 40, 217, 0.08) 100%)',
              borderColor: 'rgba(196, 181, 253, 0.4)',
              boxShadow: '0 20px 40px rgba(139, 92, 246, 0.2), 0 0 80px rgba(196, 181, 253, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.1)'
            }}>
              {/* Animated particles */}
              <div className="absolute -bottom-2 -left-2 w-12 h-12 rounded-full opacity-25 animate-bounce" style={{
                background: 'radial-gradient(circle, rgba(196, 181, 253, 0.8) 0%, transparent 70%)',
                animationDelay: '1s'
              }}></div>
              
              <div className="w-20 h-20 rounded-3xl mx-auto mb-6 flex items-center justify-center shadow-lg" 
                   style={{ background: 'linear-gradient(135deg, rgba(196, 181, 253, 0.8) 0%, rgba(139, 92, 246, 0.9) 50%, rgba(109, 40, 217, 0.8) 100%)' }}>
                <span className="text-3xl">👥</span>
              </div>
              <h2 className="text-3xl font-semibold text-white mb-4">Peer Forum</h2>
              <p className="text-gray-300 mb-6 leading-relaxed">Connect with fellow students in a safe, supportive community</p>
              <div className="inline-flex items-center space-x-2 text-yellow-400">
                <span className="animate-pulse">✩</span>
                <span className="text-sm">Coming soon...</span>
                <span className="animate-pulse">✩</span>
              </div>
            </div>
          </div>
        );
      case 'resources':
        return (
          <div className="flex items-center justify-center min-h-96 relative mindease-subtle-stars">
            <div className="text-center border p-12 rounded-3xl shadow-2xl backdrop-blur-xl relative z-10 max-w-md" style={{
              background: 'linear-gradient(135deg, rgba(153, 246, 228, 0.15) 0%, rgba(20, 184, 166, 0.12) 50%, rgba(15, 118, 110, 0.08) 100%)',
              borderColor: 'rgba(153, 246, 228, 0.4)',
              boxShadow: '0 20px 40px rgba(20, 184, 166, 0.2), 0 0 80px rgba(153, 246, 228, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.1)'
            }}>
              {/* Animated particles */}
              <div className="absolute top-4 right-4 w-8 h-8 rounded-full opacity-30 animate-ping" style={{
                background: 'radial-gradient(circle, rgba(153, 246, 228, 0.8) 0%, transparent 70%)'
              }}></div>
              
              <div className="w-20 h-20 rounded-3xl mx-auto mb-6 flex items-center justify-center shadow-lg" 
                   style={{ background: 'linear-gradient(135deg, rgba(153, 246, 228, 0.8) 0%, rgba(20, 184, 166, 0.9) 50%, rgba(15, 118, 110, 0.8) 100%)' }}>
                <span className="text-3xl">📚</span>
              </div>
              <h2 className="text-3xl font-semibold text-white mb-4">Resources Hub</h2>
              <p className="text-gray-300 mb-6 leading-relaxed">Wellness guides, tools, and content in regional languages</p>
              <div className="inline-flex items-center space-x-2 text-yellow-400">
                <span className="animate-pulse">✪</span>
                <span className="text-sm">Coming soon...</span>
                <span className="animate-pulse">✪</span>
              </div>
            </div>
          </div>
        );
      default:
        return <DashboardHome />;
    }
  };

  if (isAuthenticated) {
    return (
      <DashboardLayout currentPage={currentPage} onPageChange={setCurrentPage}>
        {renderDashboardContent()}
      </DashboardLayout>
    );
  }

  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <HeroSection />
        <FeaturesSection />
        <TrustSection />
        <WhyMindEaseSection />
        <TestimonialSection />
      </main>
      <Footer />
    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </LanguageProvider>
  );
}