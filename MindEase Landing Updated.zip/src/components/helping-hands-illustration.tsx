import { ImageWithFallback } from './figma/ImageWithFallback';

interface HelpingHandsIllustrationProps {
  className?: string;
  showOverlayText?: boolean;
  size?: 'sm' | 'md' | 'lg' | 'xl';
}

export function HelpingHandsIllustration({ 
  className = "", 
  showOverlayText = true,
  size = 'lg'
}: HelpingHandsIllustrationProps) {
  const sizeClasses = {
    sm: 'w-48 h-48',
    md: 'w-64 h-64', 
    lg: 'w-80 h-80',
    xl: 'w-96 h-96'
  };

  return (
    <div className={`relative ${sizeClasses[size]} ${className}`}>
      {/* Starry background container */}
      <div className="absolute inset-0 mindease-stars-bg mindease-constellation rounded-3xl overflow-hidden">
        {/* Dark gradient background */}
        <div className="absolute inset-0 bg-gradient-to-br from-[#1e3f91] via-[#425ca9] to-[#85829d] opacity-90" />
        
        {/* Glowing stars overlay */}
        <div className="absolute inset-0">
          {/* Large glowing star */}
          <div className="absolute top-8 right-12 w-3 h-3 bg-white rounded-full opacity-60 animate-pulse" />
          <div className="absolute top-8 right-12 w-6 h-0.5 bg-white opacity-40 blur-sm" />
          <div className="absolute top-8 right-12 w-0.5 h-6 bg-white opacity-40 blur-sm" />
          
          {/* Medium stars */}
          <div className="absolute top-16 left-8 w-2 h-2 bg-[#d5a672] rounded-full opacity-50 mindease-pulse" />
          <div className="absolute bottom-20 right-8 w-2 h-2 bg-white rounded-full opacity-40 mindease-bounce-subtle" />
          <div className="absolute top-1/3 left-6 w-1.5 h-1.5 bg-[#d5a672] rounded-full opacity-60" />
          
          {/* Small sparkles */}
          <div className="absolute top-12 left-1/3 w-1 h-1 bg-white rounded-full opacity-50" />
          <div className="absolute bottom-16 left-12 w-1 h-1 bg-[#d5a672] rounded-full opacity-40" />
          <div className="absolute top-20 right-1/4 w-1 h-1 bg-white rounded-full opacity-60 mindease-pulse" />
          <div className="absolute bottom-12 right-16 w-1 h-1 bg-[#d5a672] rounded-full opacity-50" />
        </div>

        {/* Main illustration with glow effect */}
        <div className="absolute inset-4 rounded-2xl overflow-hidden">
          <div className="relative w-full h-full mindease-glow">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1696542631153-749759a1032b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoZWxwaW5nJTIwaGFuZHMlMjBzdXBwb3J0JTIwbWVudGFsJTIwaGVhbHRoJTIwaWxsdXN0cmF0aW9ufGVufDF8fHx8MTc1ODE0MDI0OXww&ixlib=rb-4.1.0&q=80&w=1080"
              alt="Helping hands reaching toward each other in support"
              className="w-full h-full object-cover rounded-2xl"
            />
            
            {/* Soft glow overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-[#1e3f91]/20 via-transparent to-[#d5a672]/10 rounded-2xl" />
          </div>
        </div>

        {/* Overlay text elements */}
        {showOverlayText && (
          <>
            {/* Top-right overlay */}
            <div className="absolute top-6 right-6 mindease-glass rounded-xl px-3 py-1.5 backdrop-blur-sm">
              <span className="text-white text-sm font-medium">AI Support Online</span>
            </div>
            
            {/* Bottom-left overlay */}
            <div className="absolute bottom-6 left-6 mindease-glass rounded-xl px-3 py-1.5 backdrop-blur-sm">
              <span className="text-white text-sm font-medium">Confidential Chat</span>
            </div>
          </>
        )}

        {/* Floating elements for depth */}
        <div className="absolute top-1/4 right-1/4 w-8 h-8 border border-white/20 rounded-full mindease-floating" />
        <div className="absolute bottom-1/3 left-1/4 w-6 h-6 border border-[#d5a672]/30 rounded-full mindease-floating" style={{ animationDelay: '2s' }} />
        
        {/* Subtle particle effects */}
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-32 h-32 mindease-particles opacity-30" />
      </div>
    </div>
  );
}