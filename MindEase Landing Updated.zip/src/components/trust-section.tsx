import { ShieldCheck, EyeOff, Heart } from "lucide-react";
import { useLanguage } from "../contexts/language-context";

export function TrustSection() {
  const { t } = useLanguage();

  const trustFeatures = [
    {
      icon: ShieldCheck,
      title: t('trust.encryption.title'),
      description: t('trust.encryption.description'),
      gradient: "var(--mindease-gradient-primary)",
      bgColor: "var(--mindease-primary-lighter)",
    },
    {
      icon: EyeOff,
      title: t('trust.anonymous.title'),
      description: t('trust.anonymous.description'),
      gradient: "var(--mindease-gradient-warm)",
      bgColor: "var(--mindease-accent-lighter)",
    },
    {
      icon: Heart,
      title: "Stigma-Free Support",
      description: "Mental health support without judgment. Our platform is designed to make seeking help feel natural and comfortable.",
      gradient: "linear-gradient(135deg, var(--mindease-secondary), var(--mindease-tertiary))",
      bgColor: "var(--mindease-secondary-lighter)",
    }
  ];

  return (
    <section className="mindease-section-spacing relative overflow-hidden mindease-section-dark mindease-constellation mindease-theme-transition">
      {/* Background floating elements */}
      <div className="absolute top-32 left-10 w-36 h-36 rounded-full opacity-15 mindease-floating" style={{ background: 'var(--mindease-secondary-alpha)' }} />
      <div className="absolute bottom-20 right-16 w-24 h-24 rounded-full opacity-20 mindease-floating" style={{ 
        background: 'var(--mindease-warm-alpha)', 
        animationDelay: '-2s' 
      }} />

      <div className="mindease-container relative z-20">
        <div className="text-center mb-20">
          <h2 className="text-3xl lg:text-4xl mb-6 text-white font-bold">
            {t('trust.title')}
          </h2>
          <p className="text-lg max-w-2xl mx-auto text-gray-300">
            Your privacy and well-being are our top priorities. Every interaction is protected and confidential.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {trustFeatures.map((feature, index) => (
            <div 
              key={index} 
              className="mindease-card p-8 text-center group hover:-translate-y-1 hover:scale-105 transition-all duration-500 cursor-pointer"
              style={{ background: feature.bgColor, animationDelay: `${index * 0.3}s` }}
            >
              <div className="w-20 h-20 rounded-3xl mx-auto mb-6 flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300"
                   style={{ background: feature.gradient }}>
                <feature.icon className="h-10 w-10 text-white" />
              </div>
              
              <h3 className="text-xl mb-4 group-hover:scale-105 transition-transform duration-300 text-white font-semibold">
                {feature.title}
              </h3>
              
              <p className="text-sm leading-relaxed text-gray-300">
                {feature.description}
              </p>
            </div>
          ))}
        </div>

        {/* Additional trust indicators */}
        <div className="mt-20 text-center">
          <div className="mindease-card p-10 max-w-4xl mx-auto bg-white/95 backdrop-blur-md border border-gray-200">
            <h3 className="text-xl mb-6 text-gray-900 font-bold">
              Trusted by Students Nationwide
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center group hover:scale-110 transition-all duration-300">
                <div className="text-3xl mb-2 text-gray-900 font-bold mindease-shimmer">256-bit</div>
                <div className="text-sm text-gray-600">Encryption</div>
              </div>
              <div className="text-center group hover:scale-110 transition-all duration-300">
                <div className="text-3xl mb-2 text-gray-900 font-bold mindease-shimmer">HIPAA</div>
                <div className="text-sm text-gray-600">Compliant</div>
              </div>
              <div className="text-center group hover:scale-110 transition-all duration-300">
                <div className="text-3xl mb-2 text-gray-900 font-bold mindease-shimmer">ISO 27001</div>
                <div className="text-sm text-gray-600">Certified</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}