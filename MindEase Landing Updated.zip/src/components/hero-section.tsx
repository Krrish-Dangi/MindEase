import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { useLanguage } from "../contexts/language-context";
import { useAuth } from "../contexts/auth-context";
import { SoundEffects } from "./sound-effects";
import helpingHandsImage from "figma:asset/55f32bdd5d728ad5ba4e7ef162aa23857b6ab64b.png";

export function HeroSection() {
  const { t } = useLanguage();
  const { loginAsGuest } = useAuth();

  const handleGetStarted = () => {
    SoundEffects.playClick();
    loginAsGuest();
  };

  const handleLearnMore = () => {
    SoundEffects.playClick();
    // Scroll to features section
    document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="hero" className="relative overflow-hidden mindease-section-spacing bg-gray-900 mindease-stars-bg mindease-constellation mindease-theme-transition">
      {/* Floating background orbs */}
      <div className="absolute top-20 left-10 w-32 h-32 rounded-full mindease-floating opacity-20" style={{ background: 'var(--mindease-primary-alpha)' }} />
      <div className="absolute bottom-32 right-20 w-24 h-24 rounded-full mindease-floating opacity-30" style={{ 
        background: 'var(--mindease-accent-alpha)', 
        animationDelay: '-2s' 
      }} />
      <div className="absolute top-1/2 left-1/4 w-16 h-16 rounded-full mindease-floating opacity-25" style={{ 
        background: 'var(--mindease-warm-alpha)', 
        animationDelay: '-4s' 
      }} />

      <div className="mindease-container relative z-20">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left Column - Content */}
          <div className="space-y-8 order-2 lg:order-1">
            <div className="space-y-6">
              <h1 className="text-4xl lg:text-6xl leading-tight font-bold text-white">
                Your Mental Health Matters
              </h1>
              
              <p className="text-lg lg:text-xl leading-relaxed text-gray-300 max-w-xl">
                {t('hero.subtitle') || 'Confidential, culturally-sensitive mental health support designed specifically for Indian college students.'}
              </p>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                className="mindease-button px-8 py-4 text-white text-lg font-medium hover:scale-105 transition-all duration-300"
                onClick={handleGetStarted}
              >
                {t('hero.cta.primary') || t('hero.getStarted') || 'Get Started for Free'}
              </Button>
              
              <Button 
                variant="outline" 
                className="px-8 py-4 text-lg font-medium border-2 rounded-2xl hover:scale-105 transition-all duration-300 bg-white/80 dark:bg-gray-800/80 text-gray-900 dark:text-gray-100 border-gray-300 dark:border-gray-600 hover:bg-white dark:hover:bg-gray-800 hover:border-gray-400 dark:hover:border-gray-500"
                onClick={handleLearnMore}
              >
                {t('hero.cta.secondary') || 'Learn More'}
              </Button>
            </div>

            {/* Trust Badges */}
            <div className="flex items-center space-x-8 pt-6">
              <div className="text-center group hover:scale-110 transition-all duration-300">
                <div className="text-2xl font-bold text-white mindease-shimmer">10k+</div>
                <div className="text-sm text-gray-400">{t('hero.stats.students') || 'Students'}</div>
              </div>
              <div className="text-center group hover:scale-110 transition-all duration-300">
                <div className="text-2xl font-bold text-white mindease-shimmer">24/7</div>
                <div className="text-sm text-gray-400">{t('hero.stats.support') || 'Support'}</div>
              </div>
              <div className="text-center group hover:scale-110 transition-all duration-300">
                <div className="text-2xl font-bold text-white mindease-shimmer">100%</div>
                <div className="text-sm text-gray-400">{t('hero.stats.confidential') || 'Confidential'}</div>
              </div>
            </div>
          </div>

          {/* Right Column - Helping Hands Image */}
          <div className="relative order-1 lg:order-2 mindease-perspective">
            <div className="relative mindease-card overflow-hidden mindease-rotate-y">
              {/* Enhanced starry overlay matching the night sky theme */}
              <div className="absolute inset-0 z-10 pointer-events-none">
                {/* Subtle star particles overlay */}
                <div className="absolute inset-0 mindease-stars-bg opacity-30" />
                
                {/* Gentle constellation overlay */}
                <div className="absolute inset-0 mindease-constellation opacity-40" />
                
                {/* Soft gradient overlay to blend with palette */}
                <div className="absolute inset-0 bg-gradient-to-br from-[#1e3f91]/20 via-[#425ca9]/10 to-[#85829d]/20" />
                
                {/* Warm glow effect around the edges */}
                <div className="absolute inset-0 bg-gradient-to-r from-[#d5a672]/10 via-transparent to-[#c09c80]/10" />
              </div>
              
              {/* Main helping hands image */}
              <div className="relative z-5">
                <ImageWithFallback
                  src={helpingHandsImage}
                  alt="Two hands reaching toward each other in support, symbolizing help and kindness in mental health care"
                  className="w-full h-[400px] lg:h-[500px] object-cover"
                />
                
                {/* Soft glow effect around the image */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#1e3f91]/30 via-transparent to-[#d5a672]/20 mix-blend-soft-light" />
              </div>
              
              {/* Enhanced floating elements with improved contrast */}
              <div className="absolute top-8 right-8 z-20 mindease-glass rounded-2xl p-4 shadow-2xl border border-white/20 backdrop-blur-xl">
                <div className="flex items-center space-x-3">
                  <div className="w-4 h-4 rounded-full animate-pulse bg-green-400 shadow-lg shadow-green-400/50"></div>
                  <span className="text-sm font-medium text-white drop-shadow-lg">AI Support Online</span>
                </div>
              </div>
              
              <div className="absolute bottom-8 left-8 z-20 mindease-glass rounded-2xl p-4 shadow-2xl border border-white/20 backdrop-blur-xl">
                <div className="flex items-center space-x-3">
                  <div className="w-4 h-4 rounded-full animate-pulse bg-blue-400 shadow-lg shadow-blue-400/50"></div>
                  <span className="text-sm font-medium text-white drop-shadow-lg">Confidential Chat</span>
                </div>
              </div>
              
              {/* Additional calming elements */}
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-15 pointer-events-none">
                {/* Subtle heart pulse at the connection point */}
                <div className="w-8 h-8 rounded-full bg-gradient-to-r from-[#d5a672]/30 to-[#c09c80]/30 animate-pulse" />
                <div className="absolute inset-0 w-8 h-8 rounded-full bg-white/10 mindease-pulse" />
              </div>
              
              {/* Floating sparkles for magical effect */}
              <div className="absolute top-20 right-20 z-15 w-2 h-2 rounded-full bg-[#d5a672]/60 animate-pulse" />
              <div className="absolute bottom-24 right-16 z-15 w-1.5 h-1.5 rounded-full bg-white/70 mindease-bounce-subtle" />
              <div className="absolute top-32 left-12 z-15 w-1 h-1 rounded-full bg-[#c09c80]/80 animate-pulse" style={{ animationDelay: '1s' }} />
            </div>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="text-center mt-16">
          <div className="inline-flex flex-col items-center space-y-2 text-gray-400">
            <span className="text-sm">Discover More</span>
            <div className="w-6 h-10 border-2 border-gray-500 rounded-full flex justify-center">
              <div className="w-1 h-3 bg-gray-500 rounded-full mt-2 animate-bounce"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}