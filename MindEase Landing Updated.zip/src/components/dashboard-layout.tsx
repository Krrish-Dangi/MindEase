import { useState } from 'react';
import { Button } from './ui/button';
import { Avatar, AvatarFallback } from './ui/avatar';
import { 
  Home, 
  Brain, 
  Users, 
  GraduationCap, 
  LogOut,
  Menu,
  Settings,
  Globe,
  Phone,
  ChevronLeft,
  ChevronRight,
  Calendar
} from 'lucide-react';
import { useAuth } from '../contexts/auth-context';
import { useLanguage } from '../contexts/language-context';
import { SoundEffects } from './sound-effects';

interface DashboardLayoutProps {
  children: React.ReactNode;
  currentPage?: string;
  onPageChange?: (page: string) => void;
}

export function DashboardLayout({ children, currentPage = 'dashboard', onPageChange }: DashboardLayoutProps) {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  // Dark mode is now default and only mode
  const { user, logout, isGuest } = useAuth();
  const { t, currentLanguage, setLanguage } = useLanguage();

  const sidebarItems = [
    { id: 'dashboard', label: t('dashboard.sidebar.dashboard'), icon: Home, symbol: '✦' },
    { id: 'ai', label: t('dashboard.sidebar.ai'), icon: Brain, symbol: '✧' },
    { id: 'booking', label: 'Booking System', icon: Calendar, symbol: '✨' },
    { id: 'p2p', label: t('dashboard.sidebar.p2p'), icon: Users, symbol: '✩' },
    { id: 'resources', label: t('dashboard.sidebar.resources'), icon: GraduationCap, symbol: '✪' },
    { id: 'settings', label: 'Settings', icon: Settings, symbol: '⚙️' },
  ];

  const languages = [
    { code: 'en', name: 'English', flag: '✦' },
    { code: 'hi', name: 'हिंदी', flag: '✧' },
    { code: 'ks', name: 'کٲشُر', flag: '✩' }
  ];

  const getUserInitials = () => {
    if (!user || isGuest) return 'GU';
    return `${user.firstName[0]}${user.lastName ? user.lastName[0] : ''}`.toUpperCase();
  };

  const getUserDisplayName = () => {
    if (!user || isGuest) return 'Guest User';
    return user.firstName;
  };

  const getUserUsername = () => {
    if (!user || isGuest) return 'guest';
    return user.username;
  };

  const handleLanguageToggle = () => {
    SoundEffects.playClick();
    const currentIndex = languages.findIndex(l => l.code === currentLanguage);
    const nextIndex = (currentIndex + 1) % languages.length;
    setLanguage(languages[nextIndex].code as any);
  };

  // Dark mode only - no toggle needed

  const handleLogout = () => {
    SoundEffects.playClick();
    logout();
  };

  return (
    <div className="flex h-screen relative overflow-hidden" style={{ 
      background: 'linear-gradient(135deg, #0f1419 0%, #1a1b2e 25%, #16213e 50%, #1e3f91 100%)'
    }}>
      {/* Enhanced Dashboard Star Background with Better Vibrancy */}
      <div className="mindease-dashboard-stars"></div>
      
      {/* Multi-layered Animated Background Effects */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {/* Primary Gradient Flow */}
        <div className="absolute inset-0 opacity-25">
          <div className="mindease-gradient-flow"></div>
        </div>
        
        {/* Secondary Blue-Yellow Gradient Overlay */}
        <div className="absolute inset-0 opacity-20">
          <div className="w-full h-full bg-gradient-to-br from-blue-600/20 via-transparent to-yellow-400/15 animate-pulse"></div>
        </div>
        
        {/* Enhanced Floating Particles with MindEase Colors */}
        <div className="absolute inset-0">
          {Array.from({ length: 20 }).map((_, i) => (
            <div
              key={i}
              className="absolute rounded-full animate-pulse"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                width: `${2 + Math.random() * 3}px`,
                height: `${2 + Math.random() * 3}px`,
                background: i % 4 === 0 ? 'rgba(213, 166, 114, 0.6)' : i % 4 === 1 ? 'rgba(66, 92, 169, 0.5)' : i % 4 === 2 ? 'rgba(147, 197, 253, 0.4)' : 'rgba(255, 255, 255, 0.3)',
                opacity: 0.3,
                animationDelay: `${Math.random() * 20}s`,
                animationDuration: `${8 + Math.random() * 15}s`,
                filter: 'blur(0.5px)',
                boxShadow: `0 0 ${3 + Math.random() * 6}px currentColor`
              }}
            />
          ))}
        </div>
        
        {/* Constellation Lines Effect */}
        <svg className="absolute inset-0 w-full h-full opacity-10" viewBox="0 0 1000 1000">
          <defs>
            <linearGradient id="constellationGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="rgba(213, 166, 114, 0.4)" />
              <stop offset="50%" stopColor="rgba(66, 92, 169, 0.3)" />
              <stop offset="100%" stopColor="rgba(147, 197, 253, 0.2)" />
            </linearGradient>
          </defs>
          <path d="M200,300 L400,200 L600,350 L800,250" stroke="url(#constellationGrad)" strokeWidth="1" fill="none" opacity="0.3" />
          <path d="M150,600 L350,500 L550,650 L750,550" stroke="url(#constellationGrad)" strokeWidth="1" fill="none" opacity="0.2" />
        </svg>
        
        {/* Enhanced Wave Animation */}
        <div className="absolute inset-0 opacity-15">
          <svg className="w-full h-full" viewBox="0 0 400 400" preserveAspectRatio="none">
            <defs>
              <linearGradient id="enhancedWaveGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="rgba(30, 63, 145, 0.15)" />
                <stop offset="35%" stopColor="rgba(66, 92, 169, 0.12)" />
                <stop offset="70%" stopColor="rgba(213, 166, 114, 0.08)" />
                <stop offset="100%" stopColor="rgba(147, 197, 253, 0.1)" />
              </linearGradient>
            </defs>
            <path 
              d="M0,100 Q100,50 200,100 T400,100 L400,400 L0,400 Z" 
              fill="url(#enhancedWaveGrad)"
              className="mindease-wave-flow"
            />
          </svg>
        </div>
      </div>
      
      {/* Sidebar */}
      <div className={`${sidebarCollapsed ? 'w-16' : 'w-64'} ${mobileMenuOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0 fixed lg:relative z-30 h-full backdrop-blur-md border-r transition-all duration-300 shadow-lg`}
        style={{
          background: 'rgba(30, 63, 145, 0.15)',
          borderColor: 'rgba(133, 130, 157, 0.3)'
        }}>
        {/* Sidebar Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-700">
          {!sidebarCollapsed && (
            <div className="flex items-center space-x-3">
              <div className="h-10 w-10 rounded-2xl mindease-gradient-primary shadow-lg"></div>
              <span className="text-xl font-bold text-white">MindEase</span>
            </div>
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              SoundEffects.playClick();
              setSidebarCollapsed(!sidebarCollapsed);
            }}
            className="hidden lg:flex p-2 rounded-xl hover:bg-gray-700 text-gray-400"
          >
            {sidebarCollapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
          </Button>
        </div>

        {/* User Profile */}
        <div className="p-4 border-b border-gray-700">
          <div className="flex items-center space-x-3">
            <Avatar className="h-12 w-12">
              <AvatarFallback className="text-sm font-medium mindease-gradient-primary text-white">
                {getUserInitials()}
              </AvatarFallback>
            </Avatar>
            {!sidebarCollapsed && (
              <div>
                <p className="text-sm font-medium text-white">{getUserDisplayName()}</p>
                <p className="text-xs text-gray-400">@{getUserUsername()}</p>
              </div>
            )}
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4">
          <div className="space-y-3">
            {sidebarItems.map((item) => (
              <Button
                key={item.id}
                variant={currentPage === item.id ? "secondary" : "ghost"}
                className={`w-full justify-start ${sidebarCollapsed ? 'px-3' : 'px-4'} py-3 h-auto rounded-xl transition-all duration-300 ${
                  currentPage === item.id 
                    ? 'mindease-button text-white' 
                    : 'hover:bg-gray-700 text-gray-300'
                }`}
                onClick={() => {
                  SoundEffects.playClick();
                  onPageChange?.(item.id);
                }}
              >
                <item.icon className={`h-5 w-5 ${sidebarCollapsed ? '' : 'mr-3'}`} />
                {!sidebarCollapsed && (
                  <span className="text-sm flex-1 text-left">{item.label}</span>
                )}
                {!sidebarCollapsed && (
                  <span className="text-lg text-yellow-500">{item.symbol}</span>
                )}
              </Button>
            ))}
          </div>
        </nav>

        {/* Logout */}
        <div className="p-4 border-t border-gray-700">
          <Button
            variant="ghost"
            onClick={handleLogout}
            className={`w-full justify-start ${sidebarCollapsed ? 'px-3' : 'px-4'} py-3 h-auto rounded-xl hover:bg-red-900/20 transition-all duration-300 text-red-400`}
          >
            <LogOut className={`h-5 w-5 ${sidebarCollapsed ? '' : 'mr-3'}`} />
            {!sidebarCollapsed && <span className="text-sm">{t('dashboard.sidebar.logout')}</span>}
          </Button>
        </div>
      </div>

      {/* Mobile overlay */}
      {mobileMenuOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-20 lg:hidden"
          onClick={() => setMobileMenuOpen(false)}
        />
      )}

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Header */}
        <header className="backdrop-blur-md border-b px-6 py-4 shadow-sm" style={{
          background: 'rgba(30, 63, 145, 0.2)',
          borderColor: 'rgba(133, 130, 157, 0.3)'
        }}>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  SoundEffects.playClick();
                  setMobileMenuOpen(!mobileMenuOpen);
                }}
                className="lg:hidden rounded-xl hover:bg-gray-700 text-gray-400"
              >
                <Menu className="h-5 w-5" />
              </Button>
              <h1 className="text-2xl font-bold text-white">{t('dashboard.title')}</h1>
            </div>

            <div className="flex items-center space-x-4">
              {/* Language Toggle */}
              <Button 
                variant="ghost" 
                size="sm" 
                className="flex items-center space-x-2 rounded-xl hover:bg-gray-700 text-gray-400"
                onClick={handleLanguageToggle}
              >
                <Globe className="h-4 w-4" />
                <span className="text-lg">{languages.find(l => l.code === currentLanguage)?.flag}</span>
              </Button>

              {/* Profile */}
              <Avatar className="h-10 w-10 cursor-pointer">
                <AvatarFallback className="text-xs font-medium mindease-gradient-primary text-white">
                  {getUserInitials()}
                </AvatarFallback>
              </Avatar>

              {/* Emergency Button */}
              <Button 
                size="sm" 
                className="rounded-xl text-white shadow-lg hover:shadow-xl transition-all duration-300 px-4 hover:scale-105"
                style={{ background: 'var(--mindease-gradient-warm)' }}
                onClick={() => SoundEffects.playClick()}
              >
                <Phone className="h-4 w-4 mr-2" />
                <span className="hidden sm:inline">{t('dashboard.emergency')}</span>
              </Button>
            </div>
          </div>
        </header>

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto p-8 relative mindease-subtle-stars" style={{
          background: 'linear-gradient(135deg, rgba(26, 27, 46, 0.8) 0%, rgba(22, 33, 62, 0.9) 50%, rgba(30, 63, 145, 0.3) 100%)'
        }}>
          {children}
        </main>
      </div>
    </div>
  );
}