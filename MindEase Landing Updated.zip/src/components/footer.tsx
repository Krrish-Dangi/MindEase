import { Button } from "./ui/button";
import { Phone, Mail, Instagram, Twitter, Youtube } from "lucide-react";
import { useLanguage } from "../contexts/language-context";

export function Footer() {
  const { t } = useLanguage();
  
  return (
    <footer className="py-20 relative overflow-hidden mindease-section-dark mindease-stars-bg mindease-theme-transition">
      {/* Enhanced star field for footer */}
      <div className="absolute inset-0 z-10">
        {Array.from({ length: 40 }).map((_, i) => (
          <div
            key={i}
            className="absolute text-white/20 animate-pulse"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 20}s`,
              animationDuration: `${8 + Math.random() * 8}s`,
              fontSize: `${0.4 + Math.random() * 0.8}rem`,
            }}
          >
            ✦
          </div>
        ))}
      </div>

      {/* Background decorative elements */}
      <div className="absolute top-10 right-20 w-32 h-32 rounded-full opacity-10" style={{ background: 'var(--mindease-accent)' }} />
      <div className="absolute bottom-20 left-10 w-24 h-24 rounded-full opacity-15" style={{ background: 'var(--mindease-warm)' }} />
      
      <div className="mindease-container relative z-20">
        <div className="grid md:grid-cols-4 gap-12 mb-16">
          {/* Brand */}
          <div className="space-y-6">
            <div className="flex items-center space-x-3">
              <div className="h-10 w-10 rounded-2xl mindease-gradient-warm"></div>
              <span className="text-2xl text-white font-bold">MindEase</span>
            </div>
            <p className="text-sm text-white/80 max-w-sm leading-relaxed">
              {t('footer.description')}
            </p>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm" className="text-white/70 hover:text-white hover:bg-white/10 p-3 rounded-xl transition-all duration-300 hover:scale-110">
                <Instagram className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="sm" className="text-white/70 hover:text-white hover:bg-white/10 p-3 rounded-xl transition-all duration-300 hover:scale-110">
                <Twitter className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="sm" className="text-white/70 hover:text-white hover:bg-white/10 p-3 rounded-xl transition-all duration-300 hover:scale-110">
                <Youtube className="h-5 w-5" />
              </Button>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white mb-6 text-lg font-semibold">{t('footer.quickLinks')} ✦</h3>
            <div className="space-y-3">
              <a href="#resources" className="block text-sm text-white/80 hover:text-white hover:translate-x-1 transition-all duration-200">
                {t('footer.resources')} ✧
              </a>
              <a href="#peer-forum" className="block text-sm text-white/80 hover:text-white hover:translate-x-1 transition-all duration-200">
                {t('footer.about')} ✩
              </a>
              <a href="#book-session" className="block text-sm text-white/80 hover:text-white hover:translate-x-1 transition-all duration-200">
                {t('footer.features')} ✪
              </a>
              <a href="#admin-login" className="block text-sm text-white/80 hover:text-white hover:translate-x-1 transition-all duration-200">
                {t('footer.blog')} ✫
              </a>
            </div>
          </div>

          {/* Support */}
          <div>
            <h3 className="text-white mb-6 text-lg font-semibold">{t('footer.support')} ✧</h3>
            <div className="space-y-3">
              <a href="#faq" className="block text-sm text-white/80 hover:text-white hover:translate-x-1 transition-all duration-200">
                {t('footer.help')} ✦
              </a>
              <a href="#privacy" className="block text-sm text-white/80 hover:text-white hover:translate-x-1 transition-all duration-200">
                {t('footer.privacy')} ✩
              </a>
              <a href="#terms" className="block text-sm text-white/80 hover:text-white hover:translate-x-1 transition-all duration-200">
                {t('footer.terms')} ✪
              </a>
              <a href="#contact" className="block text-sm text-white/80 hover:text-white hover:translate-x-1 transition-all duration-200">
                {t('footer.contact')} ✫
              </a>
            </div>
          </div>

          {/* Emergency */}
          <div>
            <h3 className="text-white mb-6 text-lg font-semibold">{t('footer.emergency')} ✩</h3>
            <div className="space-y-4">
              <div className="bg-white/10 backdrop-blur-md p-4 rounded-xl border border-white/20 hover:bg-white/15 transition-all duration-300">
                <div className="flex items-center space-x-3 mb-2">
                  <Phone className="h-5 w-5 text-red-400" />
                  <span className="text-sm text-white/80">National Helpline</span>
                </div>
                <div className="text-lg text-white font-semibold">1800-233-3330</div>
              </div>
              
              <div className="bg-white/10 backdrop-blur-md p-4 rounded-xl border border-white/20 hover:bg-white/15 transition-all duration-300">
                <div className="flex items-center space-x-3 mb-2">
                  <Mail className="h-5 w-5 text-yellow-400" />
                  <span className="text-sm text-white/80">Support Email</span>
                </div>
                <div className="text-lg text-white font-semibold">help@mindease.in</div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom section */}
        <div className="pt-8 border-t border-white/20">
          <div className="flex flex-col lg:flex-row justify-between items-center space-y-6 lg:space-y-0 gap-8">
            <div className="text-sm text-white/80">
              © 2024 MindEase. {t('footer.rights')} ✦
            </div>
            
            <div className="bg-white/10 backdrop-blur-md p-6 rounded-2xl border border-white/20 max-w-lg">
              <p className="text-xs text-white/90 text-center leading-relaxed">
                <strong className="text-red-400">Important:</strong> MindEase is not a substitute for professional medical advice, diagnosis, or treatment. 
                In case of emergencies, please contact your local emergency services or call the helpline immediately. ✧
              </p>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}