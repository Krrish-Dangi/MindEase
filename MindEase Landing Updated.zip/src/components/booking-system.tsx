import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Calendar, Clock, User, Star, MapPin, Video, MessageSquare } from 'lucide-react';
import { SoundEffects } from './sound-effects';
import { useLanguage } from '../contexts/language-context';

interface Counselor {
  id: string;
  name: string;
  specialization: string;
  rating: number;
  experience: string;
  languages: string[];
  availability: 'available' | 'busy' | 'offline';
  location: string;
  sessionTypes: ('video' | 'chat' | 'in-person')[];
  nextSlot?: string;
}

interface TimeSlot {
  time: string;
  available: boolean;
  counselorId?: string;
}

export function BookingSystem() {
  const { t } = useLanguage();
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [selectedCounselor, setSelectedCounselor] = useState<string | null>(null);
  const [selectedTimeSlot, setSelectedTimeSlot] = useState<string | null>(null);

  // Mock counselors data
  const counselors: Counselor[] = [
    {
      id: '1',
      name: 'Dr. Priya Sharma',
      specialization: 'Anxiety & Stress Management',
      rating: 4.9,
      experience: '8 years',
      languages: ['English', 'Hindi', 'Punjabi'],
      availability: 'available',
      location: 'Delhi',
      sessionTypes: ['video', 'chat'],
      nextSlot: '2:00 PM Today'
    },
    {
      id: '2',
      name: 'Dr. Ravi Kumar',
      specialization: 'Depression & Mood Disorders',
      rating: 4.8,
      experience: '12 years',
      languages: ['English', 'Tamil', 'Telugu'],
      availability: 'available',
      location: 'Chennai',
      sessionTypes: ['video', 'chat', 'in-person'],
      nextSlot: '4:30 PM Today'
    },
    {
      id: '3',
      name: 'Dr. Anita Desai',
      specialization: 'Academic Stress & Career Counseling',
      rating: 4.7,
      experience: '6 years',
      languages: ['English', 'Gujarati', 'Marathi'],
      availability: 'busy',
      location: 'Mumbai',
      sessionTypes: ['video', 'chat'],
      nextSlot: '10:00 AM Tomorrow'
    },
    {
      id: '4',
      name: 'Dr. Ahmed Hassan',
      specialization: 'Relationship & Social Issues',
      rating: 4.9,
      experience: '10 years',
      languages: ['English', 'Urdu', 'Arabic'],
      availability: 'available',
      location: 'Hyderabad',
      sessionTypes: ['video', 'chat'],
      nextSlot: '6:00 PM Today'
    }
  ];

  // Mock time slots for selected date
  const getTimeSlotsForDate = (date: Date): TimeSlot[] => {
    const baseSlots = [
      '9:00 AM', '10:00 AM', '11:00 AM', '12:00 PM', 
      '2:00 PM', '3:00 PM', '4:00 PM', '5:00 PM', '6:00 PM'
    ];
    
    return baseSlots.map(time => ({
      time,
      available: Math.random() > 0.3, // Random availability
      counselorId: Math.random() > 0.5 ? counselors[Math.floor(Math.random() * counselors.length)].id : undefined
    }));
  };

  const [timeSlots, setTimeSlots] = useState<TimeSlot[]>(getTimeSlotsForDate(selectedDate));

  const handleDateSelect = (date: Date) => {
    SoundEffects.playClick();
    setSelectedDate(date);
    setTimeSlots(getTimeSlotsForDate(date));
    setSelectedTimeSlot(null);
  };

  const handleCounselorSelect = (counselorId: string) => {
    SoundEffects.playClick();
    setSelectedCounselor(selectedCounselor === counselorId ? null : counselorId);
  };

  const handleTimeSlotSelect = (time: string) => {
    SoundEffects.playClick();
    setSelectedTimeSlot(time);
  };

  const handleBookNow = (counselorId: string, timeSlot?: string) => {
    SoundEffects.playSuccess();
    const counselor = counselors.find(c => c.id === counselorId);
    const slot = timeSlot || selectedTimeSlot;
    console.log(`Booking session with ${counselor?.name} at ${slot}`);
    // Here you would integrate with your booking system
  };

  const getAvailabilityColor = (availability: string) => {
    switch (availability) {
      case 'available': return 'bg-green-100 text-green-700 border-green-200 dark:bg-green-900/30 dark:text-green-300 dark:border-green-700';
      case 'busy': return 'bg-yellow-100 text-yellow-700 border-yellow-200 dark:bg-yellow-900/30 dark:text-yellow-300 dark:border-yellow-700';
      case 'offline': return 'bg-gray-100 text-gray-700 border-gray-200 dark:bg-gray-900/30 dark:text-gray-300 dark:border-gray-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const getSessionTypeIcon = (type: string) => {
    switch (type) {
      case 'video': return <Video className="h-4 w-4" />;
      case 'chat': return <MessageSquare className="h-4 w-4" />;
      case 'in-person': return <MapPin className="h-4 w-4" />;
      default: return null;
    }
  };

  // Generate calendar days for current month
  const generateCalendarDays = () => {
    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();
    const firstDayOfMonth = new Date(currentYear, currentMonth, 1);
    const lastDayOfMonth = new Date(currentYear, currentMonth + 1, 0);
    const daysInMonth = lastDayOfMonth.getDate();
    
    const days = [];
    for (let i = 1; i <= daysInMonth; i++) {
      const date = new Date(currentYear, currentMonth, i);
      const isToday = date.toDateString() === now.toDateString();
      const isSelected = date.toDateString() === selectedDate.toDateString();
      const isPast = date < now && !isToday;
      
      days.push({
        date,
        day: i,
        isToday,
        isSelected,
        isPast,
        isAvailable: !isPast && Math.random() > 0.2 // Random availability
      });
    }
    return days;
  };

  const calendarDays = generateCalendarDays();

  return (
    <div className="space-y-8 relative mindease-subtle-stars">{/* Add star background */}

      {/* Title Bar */}
      <div className="border p-6 rounded-3xl shadow-lg backdrop-blur-lg relative z-10" style={{
        background: 'rgba(255, 255, 255, 0.08)',
        borderColor: 'rgba(133, 130, 157, 0.3)',
        boxShadow: '0 8px 32px rgba(0, 0, 0, 0.2), 0 0 20px rgba(30, 63, 145, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.1)'
      }}>
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 rounded-2xl flex items-center justify-center" style={{ background: 'var(--mindease-gradient-primary)' }}>
            <Calendar className="h-6 w-6 text-white" />
          </div>
          <div>
            <h2 className="text-3xl font-semibold text-gray-900 dark:text-white">
              Booking System ✨
            </h2>
            <p className="text-sm text-gray-700 dark:text-gray-300 mt-1">
              Schedule your session with verified counselors
            </p>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8 relative z-10">
        {/* Calendar Section */}
        <div className="lg:col-span-1">
          <Card className="border-0 rounded-3xl shadow-lg backdrop-blur-lg" style={{
            background: 'rgba(255, 255, 255, 0.08)',
            border: '1px solid rgba(133, 130, 157, 0.3)',
            boxShadow: '0 8px 32px rgba(0, 0, 0, 0.2), 0 0 20px rgba(30, 63, 145, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.1)'
          }}>
            <CardHeader>
              <CardTitle className="flex items-center text-lg">
                <Calendar className="h-5 w-5 mr-3 text-blue-500" />
                <span className="text-gray-900 dark:text-white">Select Date</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="text-center mb-4">
                  <h3 className="font-medium text-gray-900 dark:text-white">
                    {selectedDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
                  </h3>
                </div>
                
                <div className="grid grid-cols-7 gap-2 text-xs">
                  {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
                    <div key={day} className="text-center text-gray-500 dark:text-gray-400 font-medium py-2">
                      {day}
                    </div>
                  ))}
                  
                  {calendarDays.map((cal, index) => (
                    <button
                      key={index}
                      onClick={() => cal.isAvailable && !cal.isPast && handleDateSelect(cal.date)}
                      disabled={cal.isPast || !cal.isAvailable}
                      className={`
                        aspect-square rounded-lg text-sm transition-all duration-200 
                        ${cal.isSelected 
                          ? 'mindease-button text-white scale-105' 
                          : cal.isToday 
                          ? 'bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-300 border border-blue-300' 
                          : cal.isPast || !cal.isAvailable
                          ? 'text-gray-400 dark:text-gray-600 cursor-not-allowed'
                          : 'hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300'
                        }
                      `}
                    >
                      {cal.day}
                    </button>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Time Slots for Selected Date */}
          {selectedDate && (
            <Card className="border-0 rounded-3xl shadow-lg backdrop-blur-lg mt-6" style={{
              background: 'rgba(255, 255, 255, 0.08)',
              border: '1px solid rgba(133, 130, 157, 0.3)',
              boxShadow: '0 8px 32px rgba(0, 0, 0, 0.2), 0 0 20px rgba(30, 63, 145, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.1)'
            }}>
              <CardHeader>
                <CardTitle className="flex items-center text-lg">
                  <Clock className="h-5 w-5 mr-3 text-green-500" />
                  <span className="text-gray-900 dark:text-white">Available Times</span>
                </CardTitle>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  {selectedDate.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
                </p>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-3">
                  {timeSlots.map((slot, index) => (
                    <Button
                      key={index}
                      variant={selectedTimeSlot === slot.time ? "default" : "outline"}
                      size="sm"
                      disabled={!slot.available}
                      onClick={() => slot.available && handleTimeSlotSelect(slot.time)}
                      className={`
                        justify-center transition-all duration-300 
                        ${selectedTimeSlot === slot.time 
                          ? 'mindease-button text-white' 
                          : slot.available 
                          ? 'hover:scale-105 border-gray-300 dark:border-gray-600 hover:border-blue-400' 
                          : 'opacity-50 cursor-not-allowed'
                        }
                      `}
                    >
                      {slot.time}
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Counselors Section */}
        <div className="lg:col-span-2">
          <Card className="border-0 rounded-3xl shadow-lg backdrop-blur-lg" style={{
            background: 'rgba(255, 255, 255, 0.08)',
            border: '1px solid rgba(133, 130, 157, 0.3)',
            boxShadow: '0 8px 32px rgba(0, 0, 0, 0.2), 0 0 20px rgba(30, 63, 145, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.1)'
          }}>
            <CardHeader>
              <CardTitle className="flex items-center text-lg">
                <User className="h-5 w-5 mr-3 text-purple-500" />
                <span className="text-gray-900 dark:text-white">Available Counselors</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {counselors.map((counselor) => (
                  <div
                    key={counselor.id}
                    className={`
                      p-6 rounded-2xl border transition-all duration-300 cursor-pointer hover:shadow-lg
                      ${selectedCounselor === counselor.id 
                        ? 'border-blue-400 bg-blue-50 dark:bg-blue-900/20 dark:border-blue-600' 
                        : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
                      }
                    `}
                    onClick={() => handleCounselorSelect(counselor.id)}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-start space-x-4">
                        <Avatar className="h-16 w-16">
                          <AvatarFallback className="text-sm font-medium mindease-gradient-primary text-white">
                            {counselor.name.split(' ').map(n => n[0]).join('')}
                          </AvatarFallback>
                        </Avatar>
                        
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <h3 className="font-semibold text-lg text-gray-900 dark:text-white">
                              {counselor.name}
                            </h3>
                            <Badge className={getAvailabilityColor(counselor.availability)}>
                              {counselor.availability}
                            </Badge>
                          </div>
                          
                          <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                            {counselor.specialization}
                          </p>
                          
                          <div className="flex items-center space-x-4 text-sm text-gray-500 dark:text-gray-400">
                            <div className="flex items-center space-x-1">
                              <Star className="h-4 w-4 text-yellow-400 fill-current" />
                              <span>{counselor.rating}</span>
                            </div>
                            <span>•</span>
                            <span>{counselor.experience}</span>
                            <span>•</span>
                            <span>{counselor.location}</span>
                          </div>
                          
                          <div className="flex items-center space-x-2 mt-3">
                            {counselor.sessionTypes.map((type, index) => (
                              <div key={index} className="flex items-center space-x-1 bg-gray-100 dark:bg-gray-700 px-2 py-1 rounded-lg">
                                {getSessionTypeIcon(type)}
                                <span className="text-xs capitalize text-gray-600 dark:text-gray-300">{type}</span>
                              </div>
                            ))}
                          </div>
                          
                          <div className="flex flex-wrap gap-1 mt-2">
                            {counselor.languages.map((lang, index) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {lang}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                      
                      <div className="text-right">
                        <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">Next available:</p>
                        <p className="text-sm font-medium text-gray-900 dark:text-white">{counselor.nextSlot}</p>
                        
                        <Button
                          className="mt-4 mindease-button text-white hover:scale-105 transition-all duration-300"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleBookNow(counselor.id);
                          }}
                          disabled={counselor.availability === 'offline'}
                        >
                          Book Now ✨
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}