import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Globe, Network, UserCheck } from "lucide-react";
import { useLanguage } from "../contexts/language-context";

export function WhyMindEaseSection() {
  const { t } = useLanguage();
  
  return (
    <section className="mindease-section-spacing relative overflow-hidden mindease-section-dark mindease-constellation mindease-theme-transition">
      {/* Gentle star particles */}
      <div className="absolute inset-0 z-10">
        {Array.from({ length: 30 }).map((_, i) => (
          <div
            key={i}
            className="absolute animate-pulse"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 15}s`,
              animationDuration: `${6 + Math.random() * 6}s`,
              fontSize: `${0.3 + Math.random() * 0.5}rem`,
              color: 'var(--mindease-secondary)',
              opacity: 0.4,
            }}
          >
            ✦
          </div>
        ))}
      </div>

      <div className="mindease-container relative z-20">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Image */}
          <div className="relative order-2 lg:order-1 mindease-perspective">
            <div className="relative mindease-card overflow-hidden mindease-rotate-y">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1643312084884-ca4e3eb9f078?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaXZlcnNlJTIwc3R1ZGVudHMlMjBjb2xsYWJvcmF0aW9uJTIwc3VwcG9ydHxlbnwxfHx8fDE3NTgxMjUwODh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Diverse group of college students collaborating and supporting each other"
                className="w-full h-[400px] lg:h-[500px] object-cover"
              />
              
              {/* Floating statistics with dark overlay for contrast */}
              <div className="absolute top-8 left-8 bg-gray-900/80 backdrop-blur-md p-4 rounded-2xl shadow-lg border border-white/20">
                <div className="text-center">
                  <div className="text-2xl mb-1 text-white font-bold">10k+</div>
                  <div className="text-xs text-white/80">Students Helped</div>
                </div>
              </div>
              
              <div className="absolute bottom-8 right-8 bg-gray-900/80 backdrop-blur-md p-4 rounded-2xl shadow-lg border border-white/20">
                <div className="text-center">
                  <div className="text-2xl mb-1 text-white font-bold">24/7</div>
                  <div className="text-xs text-white/80">AI Support</div>
                </div>
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="space-y-10 order-1 lg:order-2">
            <div className="space-y-6">
              <h2 className="text-3xl lg:text-4xl leading-tight text-white font-bold">
                {t('why.title')}
              </h2>
              
              <p className="text-lg text-gray-300 leading-relaxed">
                Western mental health apps don't understand Indian college realities. MindEase is built specifically for your campus life, cultural context, and unique challenges.
              </p>
            </div>

            <div className="space-y-8">
              <div className="flex items-start space-x-6 group">
                <div className="flex-shrink-0 w-16 h-16 rounded-2xl flex items-center justify-center mindease-glow group-hover:scale-110 transition-transform duration-300"
                     style={{ background: 'var(--mindease-gradient-warm)' }}>
                  <Globe className="h-8 w-8 text-white" />
                </div>
                <div>
                  <h3 className="text-xl mb-3 group-hover:translate-x-2 transition-transform duration-300 text-white font-semibold">
                    {t('why.languages.title')} <span style={{ color: 'var(--mindease-accent)' }}>✦</span>
                  </h3>
                  <p className="text-sm text-gray-300 leading-relaxed">
                    {t('why.languages.description')}
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-6 group">
                <div className="flex-shrink-0 w-16 h-16 rounded-2xl flex items-center justify-center mindease-glow group-hover:scale-110 transition-transform duration-300"
                     style={{ background: 'var(--mindease-gradient-primary)' }}>
                  <Network className="h-8 w-8 text-white" />
                </div>
                <div>
                  <h3 className="text-xl mb-3 group-hover:translate-x-2 transition-transform duration-300 text-white font-semibold">
                    {t('why.understanding.title')} <span style={{ color: 'var(--mindease-accent)' }}>✧</span>
                  </h3>
                  <p className="text-sm text-gray-300 leading-relaxed">
                    {t('why.understanding.description')}
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-6 group">
                <div className="flex-shrink-0 w-16 h-16 rounded-2xl flex items-center justify-center mindease-glow group-hover:scale-110 transition-transform duration-300"
                     style={{ background: 'linear-gradient(135deg, var(--mindease-secondary), var(--mindease-tertiary))' }}>
                  <UserCheck className="h-8 w-8 text-white" />
                </div>
                <div>
                  <h3 className="text-xl mb-3 group-hover:translate-x-2 transition-transform duration-300 text-white font-semibold">
                    {t('why.stigma.title')} <span style={{ color: 'var(--mindease-accent)' }}>✩</span>
                  </h3>
                  <p className="text-sm text-gray-300 leading-relaxed">
                    {t('why.stigma.description')}
                  </p>
                </div>
              </div>
            </div>

            <div className="mindease-card p-8 border-l-4 mindease-shimmer bg-white/95 backdrop-blur-md border border-gray-200"
                 style={{ borderLeftColor: 'var(--mindease-accent)' }}>
              <p className="text-sm italic mb-3 text-gray-900 leading-relaxed">
                "Finally, a mental health platform that gets it. The Hindi support and understanding of hostel life made all the difference for me."
              </p>
              <p className="text-xs text-gray-600 font-medium">
                - Priya, Engineering Student, Delhi ✦
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}