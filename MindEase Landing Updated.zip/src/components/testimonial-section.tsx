import { Card, CardContent } from "./ui/card";
import { Star, MessageSquare } from "lucide-react";
import { useLanguage } from "../contexts/language-context";

export function TestimonialSection() {
  const { t } = useLanguage();
  
  const testimonials = [
    {
      name: t('testimonials.student1.name'),
      role: t('testimonials.student1.location'),
      content: t('testimonials.student1.text'),
      rating: 5,
      gradient: "var(--mindease-gradient-primary)",
      bgColor: "rgba(255, 255, 255, 0.1)",
    },
    {
      name: t('testimonials.student2.name'),
      role: t('testimonials.student2.location'),
      content: t('testimonials.student2.text'),
      rating: 5,
      gradient: "var(--mindease-gradient-warm)",
      bgColor: "rgba(255, 255, 255, 0.1)",
    },
    {
      name: t('testimonials.student3.name'),
      role: t('testimonials.student3.location'),
      content: t('testimonials.student3.text'),
      rating: 5,
      gradient: "linear-gradient(135deg, var(--mindease-secondary), var(--mindease-tertiary))",
      bgColor: "rgba(255, 255, 255, 0.1)",
    }
  ];

  return (
    <section className="mindease-section-spacing relative overflow-hidden mindease-section-dark mindease-stars-bg mindease-theme-transition">
      {/* Enhanced star field for testimonials */}
      <div className="absolute inset-0 z-10">
        {Array.from({ length: 50 }).map((_, i) => (
          <div
            key={i}
            className="absolute text-white/20 animate-pulse"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 15}s`,
              animationDuration: `${7 + Math.random() * 5}s`,
              fontSize: `${0.4 + Math.random() * 0.7}rem`,
            }}
          >
            ✦
          </div>
        ))}
      </div>

      <div className="mindease-container relative z-20">
        <div className="text-center mb-20">
          <h2 className="text-3xl lg:text-4xl mb-6 text-white font-bold">
            {t('testimonials.title')}
          </h2>
          <p className="text-lg max-w-2xl mx-auto text-white/80">
            {t('testimonials.subtitle')}
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card 
              key={index}
              className="mindease-card border-0 hover:-translate-y-1 transition-all duration-500 group mindease-pulse bg-white/95 border-gray-200 backdrop-blur-md"
              style={{ animationDelay: `${index * 0.2}s` }}
            >
              <CardContent className="p-8">
                <div className="flex items-center mb-6">
                  <div className="w-12 h-12 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300"
                       style={{ background: testimonial.gradient }}>
                    <MessageSquare className="h-6 w-6 text-white" />
                  </div>
                </div>
                
                <p className="text-sm leading-relaxed mb-8 text-gray-900">
                  "{testimonial.content}"
                </p>
                
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-sm mb-1 text-gray-900 font-medium">
                      {testimonial.name}
                    </div>
                    <div className="text-xs text-gray-600">
                      {testimonial.role}
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-1">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star 
                        key={i} 
                        className="h-4 w-4 fill-current text-yellow-500" 
                      />
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Stats section */}
        <div className="mt-20 text-center">
          <div className="mindease-card p-12 bg-white/95 border-gray-200 max-w-4xl mx-auto backdrop-blur-md">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="group">
                <div className="text-3xl lg:text-4xl mb-2 text-gray-900 font-bold group-hover:scale-110 transition-transform duration-300 mindease-shimmer">
                  10,000+ <span className="text-yellow-600">✦</span>
                </div>
                <div className="text-sm text-gray-600">
                  Students Supported
                </div>
              </div>
              <div className="group">
                <div className="text-3xl lg:text-4xl mb-2 text-gray-900 font-bold group-hover:scale-110 transition-transform duration-300 mindease-shimmer">
                  4.8/5 <span className="text-yellow-600">✧</span>
                </div>
                <div className="text-sm text-gray-600">
                  Average Rating
                </div>
              </div>
              <div className="group">
                <div className="text-3xl lg:text-4xl mb-2 text-gray-900 font-bold group-hover:scale-110 transition-transform duration-300 mindease-shimmer">
                  95% <span className="text-yellow-600">✩</span>
                </div>
                <div className="text-sm text-gray-600">
                  Feel More Confident
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}