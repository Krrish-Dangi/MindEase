import { Card, CardContent } from "./ui/card";
import { Star, Quote } from "lucide-react";
import { useLanguage } from "../contexts/language-context";

export function TestimonialSection() {
  const { t } = useLanguage();
  
  const testimonials = [
    {
      name: t('testimonials.student1.name'),
      role: t('testimonials.student1.location'),
      content: t('testimonials.student1.text'),
      rating: 5,
      bgColor: "var(--mindease-blue-50)",
    },
    {
      name: t('testimonials.student2.name'),
      role: t('testimonials.student2.location'),
      content: t('testimonials.student2.text'),
      rating: 5,
      bgColor: "var(--mindease-green-50)",
    },
    {
      name: t('testimonials.student3.name'),
      role: t('testimonials.student3.location'),
      content: t('testimonials.student3.text'),
      rating: 5,
      bgColor: "var(--mindease-purple-50)",
    }
  ];

  return (
    <section className="py-20 lg:py-32 bg-white">
      <div className="container max-w-screen-xl px-4 mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl mb-4" style={{ color: 'var(--mindease-neutral-800)' }}>
            {t('testimonials.title')}
          </h2>
          <p className="text-lg max-w-2xl mx-auto" style={{ color: 'var(--mindease-neutral-600)' }}>
            {t('testimonials.subtitle')}
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card 
              key={index}
              className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 rounded-2xl relative overflow-hidden"
              style={{ background: testimonial.bgColor }}
            >
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <Quote className="h-8 w-8 opacity-20" style={{ color: 'var(--mindease-neutral-600)' }} />
                </div>
                
                <p className="text-sm leading-relaxed mb-6" style={{ color: 'var(--mindease-neutral-700)' }}>
                  "{testimonial.content}"
                </p>
                
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-sm mb-1" style={{ color: 'var(--mindease-neutral-800)' }}>
                      {testimonial.name}
                    </div>
                    <div className="text-xs" style={{ color: 'var(--mindease-neutral-600)' }}>
                      {testimonial.role}
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-1">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star 
                        key={i} 
                        className="h-4 w-4 fill-current" 
                        style={{ color: 'var(--mindease-blue-400)' }} 
                      />
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Stats section */}
        <div className="mt-16 text-center">
          <div 
            className="inline-block p-8 rounded-3xl"
            style={{ background: 'linear-gradient(135deg, var(--mindease-green-100), var(--mindease-blue-100))' }}
          >
            <div className="grid grid-cols-3 gap-8">
              <div>
                <div className="text-2xl lg:text-3xl mb-2" style={{ color: 'var(--mindease-green-500)' }}>
                  10,000+
                </div>
                <div className="text-sm" style={{ color: 'var(--mindease-neutral-700)' }}>
                  Students Supported
                </div>
              </div>
              <div>
                <div className="text-2xl lg:text-3xl mb-2" style={{ color: 'var(--mindease-blue-500)' }}>
                  4.8/5
                </div>
                <div className="text-sm" style={{ color: 'var(--mindease-neutral-700)' }}>
                  Average Rating
                </div>
              </div>
              <div>
                <div className="text-2xl lg:text-3xl mb-2" style={{ color: 'var(--mindease-purple-500)' }}>
                  95%
                </div>
                <div className="text-sm" style={{ color: 'var(--mindease-neutral-700)' }}>
                  Feel More Confident
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}