import { Button } from "./ui/button";
import { Phone, Globe, Menu, ChevronDown } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "./ui/dropdown-menu";
import { useState } from "react";
import { SignInModal } from "./sign-in-modal";
import { SignUpModal } from "./sign-up-modal";
import { useLanguage } from "../contexts/language-context";

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isSignInOpen, setIsSignInOpen] = useState(false);
  const [isSignUpOpen, setIsSignUpOpen] = useState(false);
  const { currentLanguage, setLanguage, t } = useLanguage();

  const languages = {
    en: { name: 'English', code: 'EN' },
    hi: { name: 'हिंदी', code: 'हि' },
    ks: { name: 'کٲشُر', code: 'کش' }
  };

  return (
    <>
      <header className="sticky top-0 z-50 w-full border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
        <div className="container flex h-16 max-w-screen-xl items-center justify-between px-4">
          {/* Logo and Tagline */}
          <div className="flex items-center space-x-2">
            <div className="flex items-center space-x-2">
              <div className="h-8 w-8 rounded-full" style={{ background: 'linear-gradient(135deg, var(--mindease-blue-400), var(--mindease-purple-400))' }}></div>
              <span className="text-xl font-semibold" style={{ color: 'var(--mindease-neutral-800)' }}>MindEase</span>
            </div>
          </div>

          {/* Desktop Actions */}
          <div className="hidden md:flex items-center space-x-4">
            {/* Language Dropdown */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="flex items-center space-x-1">
                  <Globe className="h-4 w-4" />
                  <span className="text-sm">{languages[currentLanguage].code}</span>
                  <ChevronDown className="h-3 w-3" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-40">
                <DropdownMenuItem 
                  onClick={() => setLanguage('en')}
                  className={currentLanguage === 'en' ? 'bg-blue-50' : ''}
                >
                  <Globe className="h-4 w-4 mr-2" />
                  English
                </DropdownMenuItem>
                <DropdownMenuItem 
                  onClick={() => setLanguage('hi')}
                  className={currentLanguage === 'hi' ? 'bg-blue-50' : ''}
                >
                  <Globe className="h-4 w-4 mr-2" />
                  हिंदी
                </DropdownMenuItem>
                <DropdownMenuItem 
                  onClick={() => setLanguage('ks')}
                  className={currentLanguage === 'ks' ? 'bg-blue-50' : ''}
                >
                  <Globe className="h-4 w-4 mr-2" />
                  کٲشُر
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            {/* Auth Buttons */}
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => setIsSignInOpen(true)}
              className="text-sm"
              style={{ color: 'var(--mindease-neutral-700)' }}
            >
              {t('header.signIn')}
            </Button>
            
            <Button 
              size="sm" 
              onClick={() => setIsSignUpOpen(true)}
              className="rounded-full text-white shadow-md hover:shadow-lg transition-all duration-200" 
              style={{ background: 'linear-gradient(135deg, var(--mindease-blue-400), var(--mindease-blue-500))' }}
            >
              {t('header.signUp')}
            </Button>

            {/* Emergency Helpline */}
            <Button 
              size="sm" 
              className="rounded-full text-white shadow-lg hover:shadow-xl transition-all duration-200" 
              style={{ background: 'linear-gradient(135deg, var(--mindease-green-400), var(--mindease-green-500))' }}
            >
              <Phone className="h-4 w-4 mr-1" />
              <span className="hidden lg:inline">{t('header.emergency')}</span>
              <span className="lg:hidden">{t('header.help')}</span>
            </Button>
          </div>

          {/* Mobile Actions */}
          <div className="flex md:hidden items-center space-x-3">
            {/* Emergency Helpline - Mobile */}
            <Button 
              size="sm" 
              className="rounded-full text-white shadow-lg hover:shadow-xl transition-all duration-200" 
              style={{ background: 'linear-gradient(135deg, var(--mindease-green-400), var(--mindease-green-500))' }}
            >
              <Phone className="h-4 w-4" />
            </Button>

            {/* Mobile menu button */}
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              <Menu className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden border-t bg-white">
            <nav className="container px-4 py-4 flex flex-col space-y-3">
              <Button 
                variant="ghost" 
                onClick={() => {
                  setIsSignInOpen(true);
                  setIsMenuOpen(false);
                }}
                className="justify-start text-sm py-2" 
                style={{ color: 'var(--mindease-neutral-700)' }}
              >
                {t('header.signIn')}
              </Button>
              
              <Button 
                onClick={() => {
                  setIsSignUpOpen(true);
                  setIsMenuOpen(false);
                }}
                className="justify-start rounded-lg text-white shadow-md" 
                style={{ background: 'linear-gradient(135deg, var(--mindease-blue-400), var(--mindease-blue-500))' }}
              >
                {t('header.signUp')}
              </Button>
              
              {/* Mobile Language Options */}
              <div className="space-y-2 border-t pt-3" style={{ borderColor: 'var(--mindease-neutral-200)' }}>
                <p className="text-xs px-2" style={{ color: 'var(--mindease-neutral-600)' }}>Language / भाषा / زبان</p>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => setLanguage('en')}
                  className={`justify-start ${currentLanguage === 'en' ? 'bg-blue-50' : ''}`}
                >
                  <Globe className="h-4 w-4 mr-2" />
                  English
                </Button>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => setLanguage('hi')}
                  className={`justify-start ${currentLanguage === 'hi' ? 'bg-blue-50' : ''}`}
                >
                  <Globe className="h-4 w-4 mr-2" />
                  हिंदी
                </Button>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => setLanguage('ks')}
                  className={`justify-start ${currentLanguage === 'ks' ? 'bg-blue-50' : ''}`}
                >
                  <Globe className="h-4 w-4 mr-2" />
                  کٲشُر
                </Button>
              </div>
            </nav>
          </div>
        )}
      </header>

      {/* Modals */}
      <SignInModal isOpen={isSignInOpen} onClose={() => setIsSignInOpen(false)} />
      <SignUpModal isOpen={isSignUpOpen} onClose={() => setIsSignUpOpen(false)} />
    </>
  );
}