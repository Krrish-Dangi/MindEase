import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { ArrowRight, MessageCircle } from "lucide-react";
import { useLanguage } from "../contexts/language-context";
import { useAuth } from "../contexts/auth-context";

export function HeroSection() {
  const { t } = useLanguage();
  const { loginAsGuest } = useAuth();

  const handleGetStarted = () => {
    loginAsGuest();
  };

  return (
    <section className="relative overflow-hidden py-20 lg:py-32">
      {/* Background gradient */}
      <div 
        className="absolute inset-0 -z-10"
        style={{
          background: `linear-gradient(135deg, var(--mindease-blue-50) 0%, var(--mindease-purple-50) 50%, var(--mindease-green-50) 100%)`
        }}
      />
      
      <div className="container max-w-screen-xl px-4 mx-auto">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="text-4xl lg:text-5xl xl:text-6xl leading-tight" style={{ color: 'var(--mindease-neutral-800)' }}>
                {t('hero.title')}
              </h1>
              
              <p className="text-lg lg:text-xl max-w-2xl" style={{ color: 'var(--mindease-neutral-600)' }}>
                {t('hero.subtitle')}
              </p>
            </div>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                size="lg" 
                className="rounded-full px-8 py-3 text-white shadow-lg hover:shadow-xl transition-all duration-200"
                style={{ background: 'linear-gradient(135deg, var(--mindease-blue-400), var(--mindease-blue-500))' }}
                onClick={handleGetStarted}
              >
                {t('hero.getStarted')}
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              
              <Button 
                variant="outline" 
                size="lg" 
                className="rounded-full px-8 py-3 border-2 hover:bg-opacity-10 transition-all duration-200"
                style={{ 
                  borderColor: 'var(--mindease-green-400)',
                  color: 'var(--mindease-green-500)'
                }}
                onClick={handleGetStarted}
              >
                <MessageCircle className="mr-2 h-5 w-5" />
                {t('hero.chatNow')}
              </Button>
            </div>

            {/* Trust indicators */}
            <div className="flex flex-wrap gap-6 pt-4">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 rounded-full" style={{ background: 'var(--mindease-green-400)' }}></div>
                <span className="text-sm" style={{ color: 'var(--mindease-neutral-600)' }}>{t('hero.features.anonymous')}</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 rounded-full" style={{ background: 'var(--mindease-blue-400)' }}></div>
                <span className="text-sm" style={{ color: 'var(--mindease-neutral-600)' }}>{t('hero.features.available')}</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 rounded-full" style={{ background: 'var(--mindease-purple-400)' }}></div>
                <span className="text-sm" style={{ color: 'var(--mindease-neutral-600)' }}>{t('hero.features.multilingual')}</span>
              </div>
            </div>
          </div>

          {/* Image */}
          <div className="relative">
            <div className="relative rounded-3xl overflow-hidden shadow-2xl">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1701679532499-c2413aa5abb8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2xsZWdlJTIwc3R1ZGVudHMlMjBzdHVkeWluZyUyMHBlYWNlZnVsJTIwY2FtcHVzfGVufDF8fHx8MTc1ODA0OTMxMXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Students in a peaceful campus environment representing mental wellness support"
                className="w-full h-[400px] lg:h-[500px] object-cover"
              />
              
              {/* Floating elements */}
              <div 
                className="absolute top-6 right-6 p-4 rounded-2xl shadow-lg backdrop-blur-sm"
                style={{ background: 'rgba(255, 255, 255, 0.9)' }}
              >
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 rounded-full" style={{ background: 'var(--mindease-green-400)' }}></div>
                  <span className="text-sm" style={{ color: 'var(--mindease-neutral-700)' }}>AI Support Online</span>
                </div>
              </div>
              
              <div 
                className="absolute bottom-6 left-6 p-4 rounded-2xl shadow-lg backdrop-blur-sm"
                style={{ background: 'rgba(255, 255, 255, 0.9)' }}
              >
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 rounded-full" style={{ background: 'var(--mindease-blue-400)' }}></div>
                  <span className="text-sm" style={{ color: 'var(--mindease-neutral-700)' }}>Confidential Chat</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}