import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Languages, Wifi, Users } from "lucide-react";
import { useLanguage } from "../contexts/language-context";

export function WhyMindEaseSection() {
  const { t } = useLanguage();
  
  return (
    <section className="py-20 lg:py-32" style={{ background: 'var(--mindease-neutral-50)' }}>
      <div className="container max-w-screen-xl px-4 mx-auto">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Image */}
          <div className="relative order-2 lg:order-1">
            <div className="relative rounded-3xl overflow-hidden shadow-2xl">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1557734864-c78b6dfef1b1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaXZlcnNlJTIwc3R1ZGVudHMlMjBjb2xsYWJvcmF0aW9ufGVufDF8fHx8MTc1Nzk4Mjk3Nnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Diverse group of college students collaborating and supporting each other"
                className="w-full h-[400px] lg:h-[500px] object-cover"
              />
              
              {/* Floating statistics */}
              <div 
                className="absolute top-6 left-6 p-4 rounded-2xl shadow-lg backdrop-blur-sm"
                style={{ background: 'rgba(255, 255, 255, 0.95)' }}
              >
                <div className="text-center">
                  <div className="text-2xl mb-1" style={{ color: 'var(--mindease-green-500)' }}>10k+</div>
                  <div className="text-xs" style={{ color: 'var(--mindease-neutral-600)' }}>Students Helped</div>
                </div>
              </div>
              
              <div 
                className="absolute bottom-6 right-6 p-4 rounded-2xl shadow-lg backdrop-blur-sm"
                style={{ background: 'rgba(255, 255, 255, 0.95)' }}
              >
                <div className="text-center">
                  <div className="text-2xl mb-1" style={{ color: 'var(--mindease-blue-500)' }}>24/7</div>
                  <div className="text-xs" style={{ color: 'var(--mindease-neutral-600)' }}>AI Support</div>
                </div>
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="space-y-8 order-1 lg:order-2">
            <div className="space-y-4">
              <h2 className="text-3xl lg:text-4xl leading-tight" style={{ color: 'var(--mindease-neutral-800)' }}>
                {t('why.title')}
              </h2>
              
              <p className="text-lg" style={{ color: 'var(--mindease-neutral-600)' }}>
                Western mental health apps don't understand Indian college realities. MindEase is built specifically for your campus life, cultural context, and unique challenges.
              </p>
            </div>

            <div className="space-y-6">
              <div className="flex items-start space-x-4">
                <div 
                  className="flex-shrink-0 w-12 h-12 rounded-xl flex items-center justify-center"
                  style={{ background: 'var(--mindease-green-100)' }}
                >
                  <Languages className="h-6 w-6" style={{ color: 'var(--mindease-green-500)' }} />
                </div>
                <div>
                  <h3 className="text-lg mb-2" style={{ color: 'var(--mindease-neutral-800)' }}>
                    {t('why.languages.title')}
                  </h3>
                  <p className="text-sm" style={{ color: 'var(--mindease-neutral-600)' }}>
                    {t('why.languages.description')}
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div 
                  className="flex-shrink-0 w-12 h-12 rounded-xl flex items-center justify-center"
                  style={{ background: 'var(--mindease-blue-100)' }}
                >
                  <Wifi className="h-6 w-6" style={{ color: 'var(--mindease-blue-500)' }} />
                </div>
                <div>
                  <h3 className="text-lg mb-2" style={{ color: 'var(--mindease-neutral-800)' }}>
                    {t('why.understanding.title')}
                  </h3>
                  <p className="text-sm" style={{ color: 'var(--mindease-neutral-600)' }}>
                    {t('why.understanding.description')}
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div 
                  className="flex-shrink-0 w-12 h-12 rounded-xl flex items-center justify-center"
                  style={{ background: 'var(--mindease-purple-100)' }}
                >
                  <Users className="h-6 w-6" style={{ color: 'var(--mindease-purple-500)' }} />
                </div>
                <div>
                  <h3 className="text-lg mb-2" style={{ color: 'var(--mindease-neutral-800)' }}>
                    {t('why.stigma.title')}
                  </h3>
                  <p className="text-sm" style={{ color: 'var(--mindease-neutral-600)' }}>
                    {t('why.stigma.description')}
                  </p>
                </div>
              </div>
            </div>

            <div 
              className="p-6 rounded-2xl border-l-4"
              style={{ 
                background: 'var(--mindease-blue-50)',
                borderColor: 'var(--mindease-blue-400)'
              }}
            >
              <p className="text-sm italic" style={{ color: 'var(--mindease-neutral-700)' }}>
                "Finally, a mental health platform that gets it. The Hindi support and understanding of hostel life made all the difference for me."
              </p>
              <p className="text-xs mt-2" style={{ color: 'var(--mindease-neutral-600)' }}>
                - Priya, Engineering Student, Delhi
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}