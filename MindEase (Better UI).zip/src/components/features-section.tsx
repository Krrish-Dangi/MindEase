import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Bot, Calendar, MessageSquare, BookOpen } from "lucide-react";
import { useLanguage } from "../contexts/language-context";

export function FeaturesSection() {
  const { t } = useLanguage();
  
  const features = [
    {
      icon: Bot,
      title: t('features.aiChat.title'),
      description: t('features.aiChat.description'),
      emoji: "🤖",
      bgColor: "var(--mindease-blue-50)",
      iconColor: "var(--mindease-blue-500)",
    },
    {
      icon: Calendar,
      title: t('features.booking.title'),
      description: t('features.booking.description'),
      emoji: "📅",
      bgColor: "var(--mindease-green-50)",
      iconColor: "var(--mindease-green-500)",
    },
    {
      icon: MessageSquare,
      title: t('features.peer.title'),
      description: t('features.peer.description'),
      emoji: "💬",
      bgColor: "var(--mindease-purple-50)",
      iconColor: "var(--mindease-purple-500)",
    },
    {
      icon: BookOpen,
      title: t('features.resources.title'),
      description: t('features.resources.description'),
      emoji: "📚",
      bgColor: "var(--mindease-blue-50)",
      iconColor: "var(--mindease-blue-500)",
    }
  ];

  return (
    <section className="py-20 lg:py-32" style={{ background: 'var(--mindease-neutral-50)' }}>
      <div className="container max-w-screen-xl px-4 mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl mb-4" style={{ color: 'var(--mindease-neutral-800)' }}>
            {t('features.title')}
          </h2>
          <p className="text-lg max-w-2xl mx-auto" style={{ color: 'var(--mindease-neutral-600)' }}>
            Comprehensive support designed specifically for college students, combining AI technology with human care.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <Card 
              key={index} 
              className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 rounded-2xl"
              style={{ background: feature.bgColor }}
            >
              <CardHeader className="text-center pb-4">
                <div className="mx-auto mb-4 w-16 h-16 rounded-2xl flex items-center justify-center shadow-md" style={{ background: 'white' }}>
                  <feature.icon className="h-8 w-8" style={{ color: feature.iconColor }} />
                </div>
                <CardTitle className="text-lg" style={{ color: 'var(--mindease-neutral-800)' }}>
                  {feature.title} {feature.emoji}
                </CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <CardDescription className="text-sm leading-relaxed" style={{ color: 'var(--mindease-neutral-600)' }}>
                  {feature.description}
                </CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* CTA Section */}
        <div className="text-center mt-16">
          <div 
            className="inline-block p-8 rounded-3xl shadow-lg"
            style={{ background: 'linear-gradient(135deg, var(--mindease-blue-100), var(--mindease-purple-100))' }}
          >
            <h3 className="text-xl mb-3" style={{ color: 'var(--mindease-neutral-800)' }}>
              Ready to start your wellness journey?
            </h3>
            <p className="text-sm mb-6 max-w-md mx-auto" style={{ color: 'var(--mindease-neutral-600)' }}>
              Join thousands of students who are taking control of their mental health with MindEase.
            </p>
            <button 
              className="px-8 py-3 rounded-full text-white shadow-lg hover:shadow-xl transition-all duration-200 border-0"
              style={{ background: 'linear-gradient(135deg, var(--mindease-purple-400), var(--mindease-purple-500))' }}
            >
              Explore All Features
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}