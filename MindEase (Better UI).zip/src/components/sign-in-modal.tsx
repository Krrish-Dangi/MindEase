import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./ui/dialog";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Card, CardContent } from "./ui/card";
import { User, GraduationCap, Heart, Eye, EyeOff } from "lucide-react";
import { useState } from "react";
import { useLanguage } from "../contexts/language-context";
import { useAuth } from "../contexts/auth-context";

interface SignInModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SignInModal({ isOpen, onClose }: SignInModalProps) {
  const [userType, setUserType] = useState<'student' | 'counsellor' | null>(null);
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    usernameOrEmail: '',
    password: ''
  });
  const { t } = useLanguage();
  const { login } = useAuth();

  const resetModal = () => {
    setUserType(null);
    setShowPassword(false);
    setFormData({ usernameOrEmail: '', password: '' });
  };

  const handleClose = () => {
    resetModal();
    onClose();
  };

  const handleSignIn = () => {
    // Mock authentication - in real app, this would be an API call
    const mockUser = {
      id: '1',
      email: 'user@example.com',
      username: formData.usernameOrEmail.includes('@') ? formData.usernameOrEmail.split('@')[0] : formData.usernameOrEmail,
      firstName: userType === 'student' ? 'Priya' : 'Dr. Sharma',
      lastName: userType === 'student' ? 'Patel' : '',
      userType: userType!,
      college: userType === 'student' ? 'IIT Delhi' : undefined,
      year: userType === 'student' ? '3rd Year' : undefined,
      license: userType === 'counsellor' ? 'PSY12345' : undefined,
      specialization: userType === 'counsellor' ? 'Clinical Psychology' : undefined
    };
    
    login(mockUser);
    handleClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md rounded-2xl border-0 shadow-2xl">
        {!userType ? (
          <>
            <DialogHeader className="text-center pb-6">
              <DialogTitle className="text-2xl mb-2" style={{ color: 'var(--mindease-neutral-800)' }}>
                {t('auth.signIn.title')}
              </DialogTitle>
              <DialogDescription className="text-sm" style={{ color: 'var(--mindease-neutral-600)' }}>
                {t('auth.signIn.subtitle')}
              </DialogDescription>
            </DialogHeader>

            <div className="grid gap-4">
              <Card 
                className="cursor-pointer border-2 hover:shadow-lg transition-all duration-200 rounded-xl"
                style={{ borderColor: 'var(--mindease-blue-200)' }}
                onClick={() => setUserType('student')}
              >
                <CardContent className="p-6 text-center">
                  <div 
                    className="w-16 h-16 rounded-2xl mx-auto mb-4 flex items-center justify-center"
                    style={{ background: 'var(--mindease-blue-100)' }}
                  >
                    <GraduationCap className="h-8 w-8" style={{ color: 'var(--mindease-blue-500)' }} />
                  </div>
                  <h3 className="text-lg mb-2" style={{ color: 'var(--mindease-neutral-800)' }}>
                    {t('auth.student')}
                  </h3>
                  <p className="text-sm" style={{ color: 'var(--mindease-neutral-600)' }}>
                    {t('auth.student.description')}
                  </p>
                </CardContent>
              </Card>

              <Card 
                className="cursor-pointer border-2 hover:shadow-lg transition-all duration-200 rounded-xl"
                style={{ borderColor: 'var(--mindease-green-200)' }}
                onClick={() => setUserType('counsellor')}
              >
                <CardContent className="p-6 text-center">
                  <div 
                    className="w-16 h-16 rounded-2xl mx-auto mb-4 flex items-center justify-center"
                    style={{ background: 'var(--mindease-green-100)' }}
                  >
                    <Heart className="h-8 w-8" style={{ color: 'var(--mindease-green-500)' }} />
                  </div>
                  <h3 className="text-lg mb-2" style={{ color: 'var(--mindease-neutral-800)' }}>
                    {t('auth.counsellor')}
                  </h3>
                  <p className="text-sm" style={{ color: 'var(--mindease-neutral-600)' }}>
                    {t('auth.counsellor.description')}
                  </p>
                </CardContent>
              </Card>
            </div>

            <div className="text-center pt-4">
              <p className="text-xs" style={{ color: 'var(--mindease-neutral-600)' }}>
                Don't have an account?{' '}
                <button 
                  className="underline hover:no-underline"
                  style={{ color: 'var(--mindease-blue-500)' }}
                  onClick={handleClose}
                >
                  Sign up here
                </button>
              </p>
            </div>
          </>
        ) : (
          <>
            <DialogHeader className="text-center pb-6">
              <div className="flex items-center justify-center mb-4">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setUserType(null)}
                  className="mr-2"
                >
                  ←
                </Button>
                <div 
                  className="w-12 h-12 rounded-xl flex items-center justify-center"
                  style={{ 
                    background: userType === 'student' ? 'var(--mindease-blue-100)' : 'var(--mindease-green-100)' 
                  }}
                >
                  {userType === 'student' ? (
                    <GraduationCap className="h-6 w-6" style={{ color: 'var(--mindease-blue-500)' }} />
                  ) : (
                    <Heart className="h-6 w-6" style={{ color: 'var(--mindease-green-500)' }} />
                  )}
                </div>
              </div>
              <DialogTitle className="text-xl mb-2" style={{ color: 'var(--mindease-neutral-800)' }}>
                {userType === 'student' ? 'Student Sign In' : 'Counsellor Sign In'}
              </DialogTitle>
              <DialogDescription className="text-sm" style={{ color: 'var(--mindease-neutral-600)' }}>
                {userType === 'student' 
                  ? 'Access your confidential mental health companion'
                  : 'Access your counselling dashboard'
                }
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="usernameOrEmail">{t('auth.username')} or {t('auth.email')}</Label>
                <Input
                  id="usernameOrEmail"
                  type="text"
                  placeholder={userType === 'student' ? 'username or your.email@college.edu' : 'username or your.email@domain.com'}
                  className="rounded-lg"
                  value={formData.usernameOrEmail}
                  onChange={(e) => setFormData({ ...formData, usernameOrEmail: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">{t('auth.password')}</Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="Enter your password"
                    className="rounded-lg pr-10"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4" style={{ color: 'var(--mindease-neutral-600)' }} />
                    ) : (
                      <Eye className="h-4 w-4" style={{ color: 'var(--mindease-neutral-600)' }} />
                    )}
                  </Button>
                </div>
              </div>

              <div className="flex items-center justify-between text-sm">
                <a 
                  href="#forgot-password" 
                  className="hover:underline"
                  style={{ color: 'var(--mindease-blue-500)' }}
                >
                  {t('auth.forgotPassword')}
                </a>
              </div>

              <Button 
                className="w-full rounded-lg text-white shadow-md hover:shadow-lg transition-all duration-200"
                onClick={handleSignIn}
                disabled={!formData.usernameOrEmail || !formData.password}
                style={{ 
                  background: userType === 'student' 
                    ? 'linear-gradient(135deg, var(--mindease-blue-400), var(--mindease-blue-500))' 
                    : 'linear-gradient(135deg, var(--mindease-green-400), var(--mindease-green-500))'
                }}
              >
                {t('header.signIn')}
              </Button>

              {userType === 'student' && (
                <div 
                  className="p-3 rounded-lg text-center"
                  style={{ background: 'var(--mindease-blue-50)' }}
                >
                  <div className="flex items-center justify-center space-x-2 mb-1">
                    <User className="h-4 w-4" style={{ color: 'var(--mindease-blue-500)' }} />
                    <span className="text-sm" style={{ color: 'var(--mindease-blue-600)' }}>
                      {t('auth.anonymousAvailable')}
                    </span>
                  </div>
                  <p className="text-xs" style={{ color: 'var(--mindease-neutral-600)' }}>
                    You can also use MindEase without creating an account
                  </p>
                </div>
              )}
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}