import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { 
  Bot, 
  Calendar, 
  MessageSquare, 
  BookOpen,
  TrendingUp,
  Heart,
  Brain,
  Award,
  Bell
} from 'lucide-react';
import { useAuth } from '../contexts/auth-context';
import { useLanguage } from '../contexts/language-context';

export function DashboardHome() {
  const { user, isGuest } = useAuth();
  const { t } = useLanguage();
  const [selectedMood, setSelectedMood] = useState<number | null>(null);

  const moodEmojis = ['😢', '😟', '😐', '🙂', '😃'];
  const moodLabels = [
    t('dashboard.mood.bad'),
    t('dashboard.mood.low'),
    t('dashboard.mood.okay'),
    t('dashboard.mood.good'),
    t('dashboard.mood.excellent')
  ];

  const quickActions = [
    {
      icon: Bot,
      title: t('dashboard.actions.aiChat'),
      description: 'Get instant support and coping strategies',
      color: 'var(--mindease-blue-500)',
      bgColor: 'var(--mindease-blue-50)',
    },
    {
      icon: Calendar,
      title: t('dashboard.actions.bookSession'),
      description: isGuest ? 'Sign up to book counsellor sessions' : 'Schedule with a verified counsellor',
      color: 'var(--mindease-green-500)',
      bgColor: 'var(--mindease-green-50)',
    },
    {
      icon: MessageSquare,
      title: t('dashboard.actions.peerForum'),
      description: 'Connect with fellow students',
      color: 'var(--mindease-purple-500)',
      bgColor: 'var(--mindease-purple-50)',
    },
    {
      icon: BookOpen,
      title: t('dashboard.actions.resources'),
      description: 'Access wellness guides and tools',
      color: 'var(--mindease-blue-500)',
      bgColor: 'var(--mindease-blue-50)',
    }
  ];

  const getUserName = () => {
    if (isGuest) return 'there';
    return user?.firstName || 'there';
  };

  const getWelcomeMessage = () => {
    if (isGuest) {
      return t('dashboard.welcomeAnonymous');
    }
    return t('dashboard.welcome').replace('{name}', getUserName());
  };

  // Mock data for charts and stats
  const moodData = [3, 4, 2, 3, 4, 3, 4]; // Last 7 days
  const stressScore = 6; // Out of 10
  const checkinsThisWeek = 5;
  const wellnessStreak = 3;

  return (
    <div className="space-y-6">
      {/* Guest Welcome Banner */}
      {isGuest && (
        <div 
          className="bg-gradient-to-r from-blue-50 to-purple-50 border border-blue-200 rounded-2xl p-6"
        >
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold text-gray-800 mb-2">
                🎉 Welcome to MindEase Guest Mode!
              </h3>
              <p className="text-sm text-gray-600 mb-3">
                You're exploring MindEase anonymously. Create an account to unlock all features and save your progress.
              </p>
              <Button 
                size="sm" 
                className="text-white"
                style={{ background: 'linear-gradient(135deg, var(--mindease-blue-400), var(--mindease-blue-500))' }}
              >
                Sign Up for Full Access
              </Button>
            </div>
            <div className="text-4xl">👋</div>
          </div>
        </div>
      )}

      {/* Welcome Section */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
        <h2 className="text-2xl font-semibold text-gray-800 mb-4">
          {getWelcomeMessage()}
        </h2>
        
        {/* Mood Tracker */}
        <div className="space-y-3">
          <h3 className="text-lg font-medium text-gray-700">{t('dashboard.mood.title')}</h3>
          <div className="flex items-center space-x-4">
            {moodEmojis.map((emoji, index) => (
              <button
                key={index}
                onClick={() => setSelectedMood(index)}
                className={`text-3xl p-2 rounded-full transition-all duration-200 hover:scale-110 ${
                  selectedMood === index ? 'bg-blue-100 ring-2 ring-blue-400' : 'hover:bg-gray-100'
                }`}
                title={moodLabels[index]}
              >
                {emoji}
              </button>
            ))}
          </div>
          {selectedMood !== null && (
            <p className="text-sm text-gray-600 mt-2">
              You're feeling {moodLabels[selectedMood].toLowerCase()} today
            </p>
          )}
        </div>
      </div>

      {/* Wellness Overview Cards */}
      <div className="grid md:grid-cols-3 gap-6">
        {/* Mood Trends */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center text-lg">
              <TrendingUp className="h-5 w-5 mr-2" style={{ color: 'var(--mindease-blue-500)' }} />
              {t('dashboard.wellness.moodTrends')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">This week</span>
                <Badge variant="secondary" className="text-green-600 bg-green-50">Improving</Badge>
              </div>
              <div className="h-12 flex items-end justify-between space-x-1">
                {moodData.map((mood, index) => (
                  <div
                    key={index}
                    className="flex-1 rounded-t"
                    style={{
                      height: `${(mood / 5) * 100}%`,
                      background: 'var(--mindease-blue-200)',
                      minHeight: '8px'
                    }}
                  />
                ))}
              </div>
              <div className="flex justify-between text-xs text-gray-500">
                <span>Mon</span>
                <span>Sun</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stress Score */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center text-lg">
              <Brain className="h-5 w-5 mr-2" style={{ color: 'var(--mindease-purple-500)' }} />
              {t('dashboard.wellness.stressScore')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-center">
                <div className="text-3xl font-bold text-gray-800">{stressScore}/10</div>
                <p className="text-sm text-gray-600">Moderate stress level</p>
              </div>
              <Progress value={stressScore * 10} className="h-2" />
              <p className="text-xs text-gray-500">
                Lower than last week (-1.2)
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Daily Tip */}
        <Card className="border-0 shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center text-lg">
              <Heart className="h-5 w-5 mr-2" style={{ color: 'var(--mindease-green-500)' }} />
              {t('dashboard.wellness.dailyTip')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <p className="text-sm text-gray-700 leading-relaxed">
                {t('dashboard.wellness.tip')}
              </p>
              <Button size="sm" variant="outline" className="text-xs">
                Try it now
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <div>
        <h3 className="text-xl font-semibold text-gray-800 mb-4">{t('dashboard.actions.title')}</h3>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
          {quickActions.map((action, index) => (
            <Card 
              key={index}
              className="border-0 shadow-sm hover:shadow-md transition-all duration-200 cursor-pointer hover:-translate-y-1 rounded-xl"
              style={{ background: action.bgColor }}
            >
              <CardContent className="p-6 text-center">
                <div 
                  className="w-12 h-12 rounded-xl mx-auto mb-3 flex items-center justify-center shadow-sm"
                  style={{ background: 'white' }}
                >
                  <action.icon className="h-6 w-6" style={{ color: action.color }} />
                </div>
                <h4 className="font-medium text-gray-800 mb-1">{action.title}</h4>
                <p className="text-xs text-gray-600">{action.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Progress & Insights */}
      <div className="grid md:grid-cols-2 gap-6">
        {/* Progress */}
        <Card className="border-0 shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center text-lg">
              <Award className="h-5 w-5 mr-2" style={{ color: 'var(--mindease-blue-500)' }} />
              {t('dashboard.progress.title')}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-700">{t('dashboard.progress.checkins')}</p>
                <p className="text-2xl font-bold text-gray-800">{checkinsThisWeek}/7</p>
              </div>
              <div className="text-right">
                <Progress value={(checkinsThisWeek / 7) * 100} className="w-20 h-2" />
              </div>
            </div>
            
            <div className="p-3 rounded-lg" style={{ background: 'var(--mindease-green-50)' }}>
              <div className="flex items-center space-x-2">
                <span className="text-lg">🌟</span>
                <div>
                  <p className="text-sm font-medium text-gray-700">{t('dashboard.progress.streak')}</p>
                  <p className="text-xs text-gray-600">{wellnessStreak} days strong!</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Notifications */}
        <Card className="border-0 shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center text-lg">
              <Bell className="h-5 w-5 mr-2" style={{ color: 'var(--mindease-purple-500)' }} />
              {t('dashboard.notifications.title')}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="p-3 border-l-4 border-blue-400 bg-blue-50 rounded-r-lg">
              <p className="text-sm text-gray-700">{t('dashboard.notifications.workshop')}</p>
              <p className="text-xs text-gray-500 mt-1">2 hours ago</p>
            </div>
            
            <div className="p-3 border-l-4 border-green-400 bg-green-50 rounded-r-lg">
              <p className="text-sm text-gray-700">New peer support group starting Monday</p>
              <p className="text-xs text-gray-500 mt-1">1 day ago</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Footer */}
      <div className="text-center py-4">
        <p className="text-xs text-gray-500">{t('dashboard.notifications.confidential')}</p>
      </div>
    </div>
  );
}