import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./ui/dialog";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Card, CardContent } from "./ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Checkbox } from "./ui/checkbox";
import { GraduationCap, Heart, Eye, EyeOff, Shield, User } from "lucide-react";
import { useState } from "react";
import { useLanguage } from "../contexts/language-context";

interface SignUpModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SignUpModal({ isOpen, onClose }: SignUpModalProps) {
  const [userType, setUserType] = useState<'student' | 'counsellor' | null>(null);
  const [showPassword, setShowPassword] = useState(false);
  const [agreeToTerms, setAgreeToTerms] = useState(false);
  const { t } = useLanguage();

  const resetModal = () => {
    setUserType(null);
    setShowPassword(false);
    setAgreeToTerms(false);
  };

  const handleClose = () => {
    resetModal();
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md rounded-2xl border-0 shadow-2xl max-h-[90vh] overflow-y-auto">
        {!userType ? (
          <>
            <DialogHeader className="text-center pb-6">
              <DialogTitle className="text-2xl mb-2" style={{ color: 'var(--mindease-neutral-800)' }}>
                {t('auth.signUp.title')}
              </DialogTitle>
              <DialogDescription className="text-sm" style={{ color: 'var(--mindease-neutral-600)' }}>
                {t('auth.signUp.subtitle')}
              </DialogDescription>
            </DialogHeader>

            <div className="grid gap-4">
              <Card 
                className="cursor-pointer border-2 hover:shadow-lg transition-all duration-200 rounded-xl"
                style={{ borderColor: 'var(--mindease-blue-200)' }}
                onClick={() => setUserType('student')}
              >
                <CardContent className="p-6 text-center">
                  <div 
                    className="w-16 h-16 rounded-2xl mx-auto mb-4 flex items-center justify-center"
                    style={{ background: 'var(--mindease-blue-100)' }}
                  >
                    <GraduationCap className="h-8 w-8" style={{ color: 'var(--mindease-blue-500)' }} />
                  </div>
                  <h3 className="text-lg mb-2" style={{ color: 'var(--mindease-neutral-800)' }}>
                    {t('auth.student')}
                  </h3>
                  <p className="text-sm" style={{ color: 'var(--mindease-neutral-600)' }}>
                    Get instant AI support, connect with peers, and book counselling sessions
                  </p>
                </CardContent>
              </Card>

              <Card 
                className="cursor-pointer border-2 hover:shadow-lg transition-all duration-200 rounded-xl"
                style={{ borderColor: 'var(--mindease-green-200)' }}
                onClick={() => setUserType('counsellor')}
              >
                <CardContent className="p-6 text-center">
                  <div 
                    className="w-16 h-16 rounded-2xl mx-auto mb-4 flex items-center justify-center"
                    style={{ background: 'var(--mindease-green-100)' }}
                  >
                    <Heart className="h-8 w-8" style={{ color: 'var(--mindease-green-500)' }} />
                  </div>
                  <h3 className="text-lg mb-2" style={{ color: 'var(--mindease-neutral-800)' }}>
                    {t('auth.counsellor')}
                  </h3>
                  <p className="text-sm" style={{ color: 'var(--mindease-neutral-600)' }}>
                    Join our network to support students and manage your practice
                  </p>
                </CardContent>
              </Card>
            </div>

            <div className="text-center pt-4">
              <p className="text-xs" style={{ color: 'var(--mindease-neutral-600)' }}>
                Already have an account?{' '}
                <button 
                  className="underline hover:no-underline"
                  style={{ color: 'var(--mindease-blue-500)' }}
                  onClick={handleClose}
                >
                  Sign in here
                </button>
              </p>
            </div>
          </>
        ) : (
          <>
            <DialogHeader className="text-center pb-6">
              <div className="flex items-center justify-center mb-4">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setUserType(null)}
                  className="mr-2"
                >
                  ←
                </Button>
                <div 
                  className="w-12 h-12 rounded-xl flex items-center justify-center"
                  style={{ 
                    background: userType === 'student' ? 'var(--mindease-blue-100)' : 'var(--mindease-green-100)' 
                  }}
                >
                  {userType === 'student' ? (
                    <GraduationCap className="h-6 w-6" style={{ color: 'var(--mindease-blue-500)' }} />
                  ) : (
                    <Heart className="h-6 w-6" style={{ color: 'var(--mindease-green-500)' }} />
                  )}
                </div>
              </div>
              <DialogTitle className="text-xl mb-2" style={{ color: 'var(--mindease-neutral-800)' }}>
                {userType === 'student' ? 'Student Registration' : 'Counsellor Registration'}
              </DialogTitle>
              <DialogDescription className="text-sm" style={{ color: 'var(--mindease-neutral-600)' }}>
                {userType === 'student' 
                  ? 'Create your confidential account (optional - you can use MindEase anonymously)'
                  : 'Join our verified counsellor network'
                }
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4">
              {/* Basic Information */}
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="firstName">{t('auth.firstName')}</Label>
                  <Input
                    id="firstName"
                    placeholder="John"
                    className="rounded-lg"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lastName">{t('auth.lastName')}</Label>
                  <Input
                    id="lastName"
                    placeholder="Doe"
                    className="rounded-lg"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="username">{t('auth.username')}</Label>
                <Input
                  id="username"
                  type="text"
                  placeholder="Choose a unique username"
                  className="rounded-lg"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">{t('auth.email')}</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder={userType === 'student' ? 'your.email@college.edu' : 'your.email@domain.com'}
                  className="rounded-lg"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Create Password</Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="Create a strong password"
                    className="rounded-lg pr-10"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4" style={{ color: 'var(--mindease-neutral-600)' }} />
                    ) : (
                      <Eye className="h-4 w-4" style={{ color: 'var(--mindease-neutral-600)' }} />
                    )}
                  </Button>
                </div>
              </div>

              {/* Additional fields based on user type */}
              {userType === 'student' ? (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="college">{t('auth.college')}</Label>
                    <Input
                      id="college"
                      placeholder="Your college name"
                      className="rounded-lg"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="year">{t('auth.year')}</Label>
                    <Select>
                      <SelectTrigger className="rounded-lg">
                        <SelectValue placeholder="Select your year" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1st">1st Year</SelectItem>
                        <SelectItem value="2nd">2nd Year</SelectItem>
                        <SelectItem value="3rd">3rd Year</SelectItem>
                        <SelectItem value="4th">4th Year</SelectItem>
                        <SelectItem value="masters">Master's</SelectItem>
                        <SelectItem value="phd">PhD</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </>
              ) : (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="license">{t('auth.license')}</Label>
                    <Input
                      id="license"
                      placeholder="Your professional license number"
                      className="rounded-lg"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="specialization">{t('auth.specialization')}</Label>
                    <Select>
                      <SelectTrigger className="rounded-lg">
                        <SelectValue placeholder="Select your specialization" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="clinical">Clinical Psychology</SelectItem>
                        <SelectItem value="counseling">Counseling Psychology</SelectItem>
                        <SelectItem value="student-affairs">Student Affairs</SelectItem>
                        <SelectItem value="psychiatry">Psychiatry</SelectItem>
                        <SelectItem value="social-work">Social Work</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </>
              )}

              {/* Terms and Privacy */}
              <div className="flex items-start space-x-2">
                <Checkbox 
                  id="terms" 
                  checked={agreeToTerms}
                  onCheckedChange={(checked) => setAgreeToTerms(checked as boolean)}
                />
                <Label htmlFor="terms" className="text-xs leading-relaxed">
                  {t('auth.terms')}
                </Label>
              </div>

              <Button 
                className="w-full rounded-lg text-white shadow-md hover:shadow-lg transition-all duration-200"
                disabled={!agreeToTerms}
                style={{ 
                  background: userType === 'student' 
                    ? 'linear-gradient(135deg, var(--mindease-blue-400), var(--mindease-blue-500))' 
                    : 'linear-gradient(135deg, var(--mindease-green-400), var(--mindease-green-500))'
                }}
              >
                {t('auth.createAccount')}
              </Button>

              {/* Privacy assurance for students */}
              {userType === 'student' && (
                <div 
                  className="p-3 rounded-lg"
                  style={{ background: 'var(--mindease-blue-50)' }}
                >
                  <div className="flex items-center space-x-2 mb-2">
                    <Shield className="h-4 w-4" style={{ color: 'var(--mindease-blue-500)' }} />
                    <span className="text-sm" style={{ color: 'var(--mindease-blue-600)' }}>
                      {t('auth.privacyProtected')}
                    </span>
                  </div>
                  <ul className="text-xs space-y-1" style={{ color: 'var(--mindease-neutral-600)' }}>
                    <li>• Your data is encrypted and confidential</li>
                    <li>• You can delete your account anytime</li>
                    <li>• Anonymous usage option always available</li>
                  </ul>
                </div>
              )}

              {/* Anonymous option for students */}
              {userType === 'student' && (
                <div className="text-center pt-2 border-t" style={{ borderColor: 'var(--mindease-neutral-200)' }}>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    className="text-xs"
                    style={{ color: 'var(--mindease-neutral-600)' }}
                  >
                    <User className="h-3 w-3 mr-1" />
                    {t('auth.anonymousOption')}
                  </Button>
                </div>
              )}
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}