import { useState } from 'react';
import { Button } from './ui/button';
import { Avatar, AvatarFallback } from './ui/avatar';
import { 
  Home, 
  Bot, 
  MessageCircle, 
  BookOpen, 
  LogOut,
  Menu,
  Bell,
  Settings,
  Globe,
  Phone,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import { useAuth } from '../contexts/auth-context';
import { useLanguage } from '../contexts/language-context';

interface DashboardLayoutProps {
  children: React.ReactNode;
  currentPage?: string;
}

export function DashboardLayout({ children, currentPage = 'dashboard' }: DashboardLayoutProps) {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { user, logout, isGuest } = useAuth();
  const { t, currentLanguage, setLanguage } = useLanguage();

  const sidebarItems = [
    { id: 'dashboard', label: t('dashboard.sidebar.dashboard'), icon: Home },
    { id: 'ai', label: t('dashboard.sidebar.ai'), icon: Bot },
    { id: 'p2p', label: t('dashboard.sidebar.p2p'), icon: MessageCircle },
    { id: 'resources', label: t('dashboard.sidebar.resources'), icon: BookOpen },
  ];

  const languages = [
    { code: 'en', name: 'English', flag: '🇺🇸' },
    { code: 'hi', name: 'हिंदी', flag: '🇮🇳' },
    { code: 'ks', name: 'کٲشُر', flag: '🏔️' }
  ];

  const getUserInitials = () => {
    if (!user || isGuest) return 'GU';
    return `${user.firstName[0]}${user.lastName ? user.lastName[0] : ''}`.toUpperCase();
  };

  const getUserDisplayName = () => {
    if (!user || isGuest) return 'Guest User';
    return user.firstName;
  };

  const getUserUsername = () => {
    if (!user || isGuest) return 'guest';
    return user.username;
  };

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <div className={`${sidebarCollapsed ? 'w-16' : 'w-64'} ${mobileMenuOpen ? 'translate-x-0' : '-translate-x-full'} lg:translate-x-0 fixed lg:relative z-30 h-full bg-white border-r border-gray-200 transition-all duration-300`}>
        {/* Sidebar Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200">
          {!sidebarCollapsed && (
            <div className="flex items-center space-x-2">
              <div className="h-8 w-8 rounded-full" style={{ background: 'linear-gradient(135deg, var(--mindease-blue-400), var(--mindease-purple-400))' }}></div>
              <span className="text-lg font-semibold text-gray-800">MindEase</span>
            </div>
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
            className="hidden lg:flex p-1"
          >
            {sidebarCollapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
          </Button>
        </div>

        {/* User Profile */}
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center space-x-3">
            <Avatar className="h-10 w-10">
              <AvatarFallback className="text-sm font-medium" style={{ background: 'var(--mindease-blue-100)', color: 'var(--mindease-blue-600)' }}>
                {getUserInitials()}
              </AvatarFallback>
            </Avatar>
            {!sidebarCollapsed && (
              <div>
                <p className="text-sm font-medium text-gray-800">{getUserDisplayName()}</p>
                <p className="text-xs text-gray-500">@{getUserUsername()}</p>
              </div>
            )}
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4">
          <div className="space-y-2">
            {sidebarItems.map((item) => (
              <Button
                key={item.id}
                variant={currentPage === item.id ? "secondary" : "ghost"}
                className={`w-full justify-start ${sidebarCollapsed ? 'px-2' : 'px-3'} py-2 h-auto`}
                style={currentPage === item.id ? { background: 'var(--mindease-blue-50)', color: 'var(--mindease-blue-600)' } : {}}
              >
                <item.icon className={`h-5 w-5 ${sidebarCollapsed ? '' : 'mr-3'}`} />
                {!sidebarCollapsed && <span className="text-sm">{item.label}</span>}
              </Button>
            ))}
          </div>
        </nav>

        {/* Logout */}
        <div className="p-4 border-t border-gray-200">
          <Button
            variant="ghost"
            onClick={logout}
            className={`w-full justify-start ${sidebarCollapsed ? 'px-2' : 'px-3'} py-2 h-auto text-red-600 hover:text-red-700 hover:bg-red-50`}
          >
            <LogOut className={`h-5 w-5 ${sidebarCollapsed ? '' : 'mr-3'}`} />
            {!sidebarCollapsed && <span className="text-sm">{t('dashboard.sidebar.logout')}</span>}
          </Button>
        </div>
      </div>

      {/* Mobile overlay */}
      {mobileMenuOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-20 lg:hidden"
          onClick={() => setMobileMenuOpen(false)}
        />
      )}

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Header */}
        <header className="bg-white border-b border-gray-200 px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="lg:hidden"
              >
                <Menu className="h-5 w-5" />
              </Button>
              <h1 className="text-xl font-semibold text-gray-800">{t('dashboard.title')}</h1>
            </div>

            <div className="flex items-center space-x-3">
              {/* Language Toggle */}
              <Button 
                variant="ghost" 
                size="sm" 
                className="flex items-center space-x-1"
                onClick={() => {
                  const currentIndex = languages.findIndex(l => l.code === currentLanguage);
                  const nextIndex = (currentIndex + 1) % languages.length;
                  setLanguage(languages[nextIndex].code as any);
                }}
              >
                <Globe className="h-4 w-4" />
                <span className="text-sm">{languages.find(l => l.code === currentLanguage)?.flag}</span>
              </Button>

              {/* Notifications */}
              <Button variant="ghost" size="sm" className="relative">
                <Bell className="h-4 w-4" />
                <span className="absolute -top-1 -right-1 h-3 w-3 bg-red-500 rounded-full text-xs text-white flex items-center justify-center">2</span>
              </Button>

              {/* Settings */}
              <Button variant="ghost" size="sm">
                <Settings className="h-4 w-4" />
              </Button>

              {/* Profile */}
              <Avatar className="h-8 w-8 cursor-pointer">
                <AvatarFallback className="text-xs font-medium" style={{ background: 'var(--mindease-blue-100)', color: 'var(--mindease-blue-600)' }}>
                  {getUserInitials()}
                </AvatarFallback>
              </Avatar>

              {/* Emergency Button */}
              <Button 
                size="sm" 
                className="rounded-full text-white shadow-lg hover:shadow-xl transition-all duration-200" 
                style={{ background: 'linear-gradient(135deg, var(--mindease-green-400), var(--mindease-green-500))' }}
              >
                <Phone className="h-4 w-4 mr-1" />
                <span className="hidden sm:inline">{t('dashboard.emergency')}</span>
              </Button>
            </div>
          </div>
        </header>

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto p-6">
          {children}
        </main>
      </div>
    </div>
  );
}