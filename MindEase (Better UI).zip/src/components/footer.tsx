import { Button } from "./ui/button";
import { Phone, Mail, Instagram, Twitter, Youtube } from "lucide-react";
import { useLanguage } from "../contexts/language-context";

export function Footer() {
  const { t } = useLanguage();
  
  return (
    <footer className="py-16" style={{ background: 'var(--mindease-neutral-800)' }}>
      <div className="container max-w-screen-xl px-4 mx-auto">
        <div className="grid md:grid-cols-4 gap-8 mb-12">
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <div className="h-8 w-8 rounded-full" style={{ background: 'linear-gradient(135deg, var(--mindease-blue-400), var(--mindease-purple-400))' }}></div>
              <span className="text-xl text-white">MindEase</span>
            </div>
            <p className="text-sm text-gray-400 max-w-sm">
              {t('footer.description')}
            </p>
            <div className="flex items-center space-x-3">
              <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white p-2">
                <Instagram className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white p-2">
                <Twitter className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white p-2">
                <Youtube className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white mb-4">{t('footer.quickLinks')}</h3>
            <div className="space-y-2">
              <a href="#resources" className="block text-sm text-gray-400 hover:text-white transition-colors">
                {t('footer.resources')}
              </a>
              <a href="#peer-forum" className="block text-sm text-gray-400 hover:text-white transition-colors">
                {t('footer.about')}
              </a>
              <a href="#book-session" className="block text-sm text-gray-400 hover:text-white transition-colors">
                {t('footer.features')}
              </a>
              <a href="#admin-login" className="block text-sm text-gray-400 hover:text-white transition-colors">
                {t('footer.blog')}
              </a>
            </div>
          </div>

          {/* Support */}
          <div>
            <h3 className="text-white mb-4">{t('footer.support')}</h3>
            <div className="space-y-2">
              <a href="#faq" className="block text-sm text-gray-400 hover:text-white transition-colors">
                {t('footer.help')}
              </a>
              <a href="#privacy" className="block text-sm text-gray-400 hover:text-white transition-colors">
                {t('footer.privacy')}
              </a>
              <a href="#terms" className="block text-sm text-gray-400 hover:text-white transition-colors">
                {t('footer.terms')}
              </a>
              <a href="#contact" className="block text-sm text-gray-400 hover:text-white transition-colors">
                {t('footer.contact')}
              </a>
            </div>
          </div>

          {/* Emergency */}
          <div>
            <h3 className="text-white mb-4">{t('footer.emergency')}</h3>
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <Phone className="h-4 w-4 text-red-400" />
                <span className="text-sm text-gray-400">National Helpline</span>
              </div>
              <div className="text-sm text-white">1800-233-3330</div>
              
              <div className="flex items-center space-x-2 mt-4">
                <Mail className="h-4 w-4" style={{ color: 'var(--mindease-blue-400)' }} />
                <span className="text-sm text-gray-400">Support Email</span>
              </div>
              <div className="text-sm text-white">help@mindease.in</div>
            </div>
          </div>
        </div>

        {/* Bottom section */}
        <div className="pt-8 border-t border-gray-700">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="text-sm text-gray-400">
              © 2024 MindEase. {t('footer.rights')}
            </div>
            
            <div 
              className="p-4 rounded-xl border"
              style={{ 
                background: 'var(--mindease-neutral-700)',
                borderColor: 'var(--mindease-neutral-600)'
              }}
            >
              <p className="text-xs text-gray-400 max-w-md text-center">
                <strong className="text-yellow-400">Important:</strong> MindEase is not a substitute for professional medical advice, diagnosis, or treatment. 
                In case of emergencies, please contact your local emergency services or call the helpline immediately.
              </p>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}