import { Shield, Eye, Heart } from "lucide-react";
import { useLanguage } from "../contexts/language-context";

export function TrustSection() {
  const { t } = useLanguage();
  
  const trustFeatures = [
    {
      icon: Shield,
      title: t('trust.encryption.title'),
      description: t('trust.encryption.description'),
      iconColor: "var(--mindease-green-500)",
    },
    {
      icon: Eye,
      title: t('trust.anonymous.title'),
      description: t('trust.anonymous.description'),
      iconColor: "var(--mindease-blue-500)",
    },
    {
      icon: Heart,
      title: "Stigma-Free Support",
      description: "Mental health support without judgment. Our platform is designed to make seeking help feel natural and comfortable.",
      iconColor: "var(--mindease-purple-500)",
    }
  ];

  return (
    <section className="py-20 lg:py-32 bg-white">
      <div className="container max-w-screen-xl px-4 mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl mb-4" style={{ color: 'var(--mindease-neutral-800)' }}>
            {t('trust.title')}
          </h2>
          <p className="text-lg max-w-2xl mx-auto" style={{ color: 'var(--mindease-neutral-600)' }}>
            {t('trust.subtitle')}
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 lg:gap-12">
          {trustFeatures.map((feature, index) => (
            <div key={index} className="text-center group">
              <div className="relative mb-6">
                <div 
                  className="mx-auto w-20 h-20 rounded-full flex items-center justify-center shadow-lg group-hover:shadow-xl transition-all duration-300"
                  style={{ background: `${feature.iconColor}15` }}
                >
                  <feature.icon 
                    className="h-10 w-10 group-hover:scale-110 transition-transform duration-300" 
                    style={{ color: feature.iconColor }} 
                  />
                </div>
                
                {/* Decorative rings */}
                <div 
                  className="absolute inset-0 mx-auto w-20 h-20 rounded-full opacity-20 animate-pulse"
                  style={{ background: `${feature.iconColor}10` }}
                />
              </div>
              
              <h3 className="text-xl mb-3 group-hover:text-opacity-80 transition-colors" style={{ color: 'var(--mindease-neutral-800)' }}>
                {feature.title}
              </h3>
              
              <p className="text-sm leading-relaxed max-w-sm mx-auto" style={{ color: 'var(--mindease-neutral-600)' }}>
                {feature.description}
              </p>
            </div>
          ))}
        </div>

        {/* Trust badges */}
        <div className="mt-16 text-center">
          <div 
            className="inline-flex items-center space-x-8 p-6 rounded-2xl"
            style={{ background: 'var(--mindease-neutral-50)' }}
          >
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 rounded-full" style={{ background: 'var(--mindease-green-400)' }} />
              <span className="text-sm" style={{ color: 'var(--mindease-neutral-700)' }}>HIPAA Compliant</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 rounded-full" style={{ background: 'var(--mindease-blue-400)' }} />
              <span className="text-sm" style={{ color: 'var(--mindease-neutral-700)' }}>SSL Encrypted</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 rounded-full" style={{ background: 'var(--mindease-purple-400)' }} />
              <span className="text-sm" style={{ color: 'var(--mindease-neutral-700)' }}>Zero Data Sharing</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}