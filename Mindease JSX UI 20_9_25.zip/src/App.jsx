import { useState, useEffect } from "react";
import { Header } from "./components/header.jsx";
import { HeroSection } from "./components/hero-section.jsx";
import { FeaturesSection } from "./components/features-section.jsx";
import { TrustSection } from "./components/trust-section.jsx";
import { WhyMindEaseSection } from "./components/why-mindease-section.jsx";
import { TestimonialSection } from "./components/testimonial-section.jsx";
import { Footer } from "./components/footer.jsx";
import { SplashScreen } from "./components/splash-screen.jsx";
import { DashboardLayout } from "./components/dashboard-layout.jsx";
import { DashboardHome } from "./components/dashboard-home.jsx";
import { BookingSystem } from "./components/booking-system.jsx";
import { SettingsPage } from "./components/settings-page.jsx";
import { AISupport } from "./components/ai-support.jsx";
import { PeerForum } from "./components/peer-forum.jsx";
import { ResourceHub } from "./components/resource-hub.jsx";
import { LanguageProvider } from "./contexts/language-context.jsx";
import { AuthProvider, useAuth } from "./contexts/auth-context.jsx";
import { ThemeProvider, useTheme } from "./contexts/theme-context.jsx";

function AppContent() {
  const { isAuthenticated } = useAuth();
  const [showSplash, setShowSplash] = useState(!isAuthenticated);
  const [currentPage, setCurrentPage] = useState('home');

  // Handle browser navigation and page routing
  useEffect(() => {
    const handlePopState = () => {
      const path = window.location.pathname;
      const pageFromPath = getPageFromPath(path);
      setCurrentPage(pageFromPath);
    };

    const handleNavigate = (event) => {
      setCurrentPage(event.detail.page);
    };

    // Set initial page based on URL
    const initialPath = window.location.pathname;
    const initialPage = getPageFromPath(initialPath);
    setCurrentPage(initialPage);

    // Listen for browser navigation
    window.addEventListener('popstate', handlePopState);
    window.addEventListener('navigate', handleNavigate);

    return () => {
      window.removeEventListener('popstate', handlePopState);
      window.removeEventListener('navigate', handleNavigate);
    };
  }, []);

  // Map URL paths to page IDs
  const getPageFromPath = (path) => {
    if (path === '/' || path === '/home') return 'home';
    if (path === '/dashboard') return 'dashboard';
    if (path === '/ai-support') return 'ai';
    if (path === '/booking') return 'booking';
    if (path === '/peer-forum') return 'p2p';
    if (path === '/resource-hub') return 'resources';
    if (path === '/settings') return 'settings';
    return 'home';
  };

  if (showSplash && !isAuthenticated) {
    return <SplashScreen onComplete={() => setShowSplash(false)} />;
  }

  const renderDashboardContent = () => {
    switch (currentPage) {
      case 'dashboard':
        return <DashboardHome />;
      case 'booking':
        return <BookingSystem />;
      case 'settings':
        return <SettingsPage />;
      case 'ai':
        return <AISupport />;
      case 'p2p':
        return <PeerForum />;
      case 'resources':
        return <ResourceHub />;
      default:
        return <DashboardHome />;
    }
  };

  if (isAuthenticated && currentPage !== 'home') {
    return (
      <DashboardLayout currentPage={currentPage}>
        {renderDashboardContent()}
      </DashboardLayout>
    );
  }

  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <HeroSection />
        <FeaturesSection />
        <TrustSection />
        <WhyMindEaseSection />
        <TestimonialSection />
      </main>
      <Footer />
    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <ThemeProvider>
          <AppContent />
        </ThemeProvider>
      </AuthProvider>
    </LanguageProvider>
  );
}