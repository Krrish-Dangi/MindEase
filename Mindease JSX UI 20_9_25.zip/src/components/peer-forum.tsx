import { useTheme } from "../contexts/theme-context";

export function PeerForum() {
  const { theme } = useTheme();

  return (
    <div className="flex items-center justify-center min-h-96 relative mindease-subtle-stars">
      <div className="text-center border p-12 rounded-3xl shadow-2xl backdrop-blur-xl relative z-10 max-w-md" style={{
        background: theme === 'light'
          ? 'rgba(255, 255, 255, 0.95)'
          : 'linear-gradient(135deg, rgba(196, 181, 253, 0.15) 0%, rgba(139, 92, 246, 0.12) 50%, rgba(109, 40, 217, 0.08) 100%)',
        borderColor: theme === 'light'
          ? 'rgba(139, 92, 246, 0.3)'
          : 'rgba(196, 181, 253, 0.4)',
        boxShadow: theme === 'light'
          ? '0 20px 40px rgba(139, 92, 246, 0.1), 0 0 80px rgba(147, 51, 234, 0.05), inset 0 1px 0 rgba(255, 255, 255, 0.5)'
          : '0 20px 40px rgba(139, 92, 246, 0.2), 0 0 80px rgba(196, 181, 253, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.1)'
      }}>
        {/* Animated particles */}
        <div className="absolute -bottom-2 -left-2 w-12 h-12 rounded-full opacity-25 animate-bounce" style={{
          background: theme === 'light'
            ? 'radial-gradient(circle, rgba(139, 92, 246, 0.6) 0%, transparent 70%)'
            : 'radial-gradient(circle, rgba(196, 181, 253, 0.8) 0%, transparent 70%)',
          animationDelay: '1s'
        }}></div>
        
        <div className="w-20 h-20 rounded-3xl mx-auto mb-6 flex items-center justify-center shadow-lg" 
             style={{ background: 'linear-gradient(135deg, rgba(196, 181, 253, 0.8) 0%, rgba(139, 92, 246, 0.9) 50%, rgba(109, 40, 217, 0.8) 100%)' }}>
          <span className="text-3xl">👥</span>
        </div>
        <h2 className={`text-3xl font-semibold mb-4 ${theme === 'light' ? 'text-gray-900' : 'text-white'}`}>Peer Forum</h2>
        <p className={`mb-6 leading-relaxed ${theme === 'light' ? 'text-gray-700' : 'text-gray-300'}`}>Connect with fellow students in a safe, supportive community</p>
        <div className={`inline-flex items-center space-x-2 ${theme === 'light' ? 'text-orange-600' : 'text-yellow-400'}`}>
          <span className="animate-pulse">✩</span>
          <span className="text-sm">Coming soon...</span>
          <span className="animate-pulse">✩</span>
        </div>
      </div>
    </div>
  );
}