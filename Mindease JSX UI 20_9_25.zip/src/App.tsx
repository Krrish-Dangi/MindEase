import { useState, useEffect } from "react";
import { Header } from "./components/header";
import { HeroSection } from "./components/hero-section";
import { FeaturesSection } from "./components/features-section";
import { TrustSection } from "./components/trust-section";
import { WhyMindEaseSection } from "./components/why-mindease-section";
import { TestimonialSection } from "./components/testimonial-section";
import { Footer } from "./components/footer";
import { SplashScreen } from "./components/splash-screen";
import { DashboardLayout } from "./components/dashboard-layout";
import { DashboardHome } from "./components/dashboard-home";
import { BookingSystem } from "./components/booking-system";
import { SettingsPage } from "./components/settings-page";
import { AISupport } from "./components/ai-support";
import { PeerForum } from "./components/peer-forum";
import { ResourceHub } from "./components/resource-hub";
import { LanguageProvider } from "./contexts/language-context";
import { AuthProvider, useAuth } from "./contexts/auth-context";
import { ThemeProvider, useTheme } from "./contexts/theme-context";

function AppContent() {
  const { isAuthenticated } = useAuth();
  const [showSplash, setShowSplash] = useState(!isAuthenticated);
  const [currentPage, setCurrentPage] = useState('home');

  // Handle browser navigation and page routing
  useEffect(() => {
    const handlePopState = () => {
      const path = window.location.pathname;
      const pageFromPath = getPageFromPath(path);
      setCurrentPage(pageFromPath);
    };

    const handleNavigate = (event: CustomEvent) => {
      setCurrentPage(event.detail.page);
    };

    // Set initial page based on URL
    const initialPath = window.location.pathname;
    const initialPage = getPageFromPath(initialPath);
    setCurrentPage(initialPage);

    // Listen for browser navigation
    window.addEventListener('popstate', handlePopState);
    window.addEventListener('navigate', handleNavigate as EventListener);

    return () => {
      window.removeEventListener('popstate', handlePopState);
      window.removeEventListener('navigate', handleNavigate as EventListener);
    };
  }, []);

  // Map URL paths to page IDs
  const getPageFromPath = (path: string): string => {
    if (path === '/' || path === '/home') return 'home';
    if (path === '/dashboard') return 'dashboard';
    if (path === '/ai-support') return 'ai';
    if (path === '/booking') return 'booking';
    if (path === '/peer-forum') return 'p2p';
    if (path === '/resource-hub') return 'resources';
    if (path === '/settings') return 'settings';
    return 'home';
  };

  if (showSplash && !isAuthenticated) {
    return <SplashScreen onComplete={() => setShowSplash(false)} />;
  }

  const renderDashboardContent = () => {
    switch (currentPage) {
      case 'dashboard':
        return <DashboardHome />;
      case 'booking':
        return <BookingSystem />;
      case 'settings':
        return <SettingsPage />;
      case 'ai':
        return <AISupport />;
      case 'p2p':
        return <PeerForum />;
      case 'resources':
        return <ResourceHub />;
      default:
        return <DashboardHome />;
    }
  };

  if (isAuthenticated && currentPage !== 'home') {
    return (
      <DashboardLayout currentPage={currentPage}>
        {renderDashboardContent()}
      </DashboardLayout>
    );
  }

  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <HeroSection />
        <FeaturesSection />
        <TrustSection />
        <WhyMindEaseSection />
        <TestimonialSection />
      </main>
      <Footer />
    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <ThemeProvider>
          <AppContent />
        </ThemeProvider>
      </AuthProvider>
    </LanguageProvider>
  );
}