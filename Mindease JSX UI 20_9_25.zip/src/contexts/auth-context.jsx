import React, { createContext, useContext, useState } from 'react';

const AuthContext = createContext(undefined);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);

  const login = (userData) => {
    setUser(userData);
    // Navigate to dashboard after login
    window.history.pushState({}, '', '/dashboard');
    window.dispatchEvent(new CustomEvent('navigate', { detail: { page: 'dashboard' } }));
  };

  const loginAsGuest = () => {
    const guestUser = {
      id: 'guest',
      email: 'guest@mindease.com',
      username: 'guest',
      firstName: 'Guest',
      lastName: 'User',
      userType: 'student',
      isGuest: true
    };
    setUser(guestUser);
    // Navigate to dashboard after guest login
    window.history.pushState({}, '', '/dashboard');
    window.dispatchEvent(new CustomEvent('navigate', { detail: { page: 'dashboard' } }));
  };

  const logout = () => {
    setUser(null);
    // Navigate to home after logout
    window.history.pushState({}, '', '/');
    window.dispatchEvent(new CustomEvent('navigate', { detail: { page: 'home' } }));
  };

  const updateUser = (updates) => {
    if (user) {
      setUser({ ...user, ...updates });
    }
  };

  const isAuthenticated = user !== null;
  const isGuest = user?.isGuest || false;

  return (
    <AuthContext.Provider value={{ user, isAuthenticated, isGuest, login, loginAsGuest, logout, updateUser }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}