
  # MindEase Landing Updated (1)

  This is a code bundle for MindEase Landing Updated (1). The original project is available at https://www.figma.com/design/2q7S3thYzIgXAFyJ9PdRXm/MindEase-Landing-Updated--1-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  