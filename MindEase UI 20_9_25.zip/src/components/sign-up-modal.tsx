import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Card, CardContent } from "./ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Checkbox } from "./ui/checkbox";
import { GraduationCap, Heart, Eye, EyeOff, ShieldCheck, UserCheck } from "lucide-react";
import { useState } from "react";
import { useLanguage } from "../contexts/language-context";
import { CustomModal } from "./custom-modal";

interface SignUpModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SignUpModal({ isOpen, onClose }: SignUpModalProps) {
  const [userType, setUserType] = useState<'student' | 'counsellor' | null>(null);
  const [showPassword, setShowPassword] = useState(false);
  const [agreeToTerms, setAgreeToTerms] = useState(false);
  const { t } = useLanguage();

  const resetModal = () => {
    setUserType(null);
    setShowPassword(false);
    setAgreeToTerms(false);
  };

  const handleClose = () => {
    resetModal();
    onClose();
  };

  return (
    <CustomModal isOpen={isOpen} onClose={handleClose} className="max-h-[90vh] overflow-y-auto">
      {!userType ? (
        <>
          <div className="text-center pb-6">
            <h2 className="text-3xl mb-2 text-gray-900 font-bold">
              {t('auth.signUp.title') || 'Sign Up'}
            </h2>
            <p className="text-sm text-gray-600">
              {t('auth.signUp.subtitle') || 'Choose your account type'}
            </p>
          </div>

          <div className="grid gap-6">
            <Card 
              className="cursor-pointer border-2 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 rounded-2xl group border-blue-200 hover:border-blue-400"
              style={{
                background: 'linear-gradient(135deg, rgba(59, 130, 246, 0.05) 0%, rgba(147, 197, 253, 0.08) 50%, rgba(191, 219, 254, 0.05) 100%)'
              }}
              onClick={() => setUserType('student')}
            >
              <CardContent className="px-4 py-3 text-center">
                <div className="w-12 h-12 rounded-xl mx-auto mb-2 flex items-center justify-center group-hover:scale-110 transition-transform duration-300"
                     style={{ background: 'linear-gradient(135deg, rgba(147, 197, 253, 0.8) 0%, rgba(59, 130, 246, 0.9) 50%, rgba(37, 99, 235, 0.8) 100%)' }}>
                  <GraduationCap className="h-6 w-6 text-white" />
                </div>
                <h3 className="text-base mb-1 text-gray-900 font-semibold">
                  {t('auth.student') || 'Student'} <span className="text-yellow-500">✦</span>
                </h3>
                <p className="text-xs text-gray-600 leading-tight">
                  Get instant AI support, connect with peers, and book counselling sessions
                </p>
              </CardContent>
            </Card>

            <Card 
              className="cursor-pointer border-2 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 rounded-2xl group border-orange-200 hover:border-orange-400"
              style={{
                background: 'linear-gradient(135deg, rgba(251, 146, 60, 0.05) 0%, rgba(253, 186, 116, 0.08) 50%, rgba(254, 215, 170, 0.05) 100%)'
              }}
              onClick={() => setUserType('counsellor')}
            >
              <CardContent className="px-4 py-3 text-center">
                <div className="w-12 h-12 rounded-xl mx-auto mb-2 flex items-center justify-center group-hover:scale-110 transition-transform duration-300"
                     style={{ background: 'var(--mindease-gradient-warm)' }}>
                  <Heart className="h-6 w-6 text-white" />
                </div>
                <h3 className="text-base mb-1 text-gray-900 font-semibold">
                  {t('auth.counsellor') || 'Counsellor'} <span className="text-yellow-500">✧</span>
                </h3>
                <p className="text-xs text-gray-600 leading-tight">
                  Join our network to support students and manage your practice
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="text-center pt-6">
            <p className="text-xs text-gray-600">
              Already have an account?{' '}
              <button 
                className="underline hover:no-underline font-medium text-blue-600 hover:text-blue-800"
                onClick={handleClose}
              >
                Sign in here ✩
              </button>
            </p>
          </div>
        </>
      ) : (
        <>
          <div className="text-center pb-8">
            <div className="flex items-center justify-center mb-6">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setUserType(null)}
                className="mr-4 rounded-xl hover:bg-gray-100 text-gray-600"
              >
                ← Back
              </Button>
              <div className="w-16 h-16 rounded-3xl flex items-center justify-center"
                   style={{ 
                     background: userType === 'student' ? 'linear-gradient(135deg, rgba(147, 197, 253, 0.8) 0%, rgba(59, 130, 246, 0.9) 50%, rgba(37, 99, 235, 0.8) 100%)' : 'var(--mindease-gradient-warm)'
                   }}>
                {userType === 'student' ? (
                  <GraduationCap className="h-8 w-8 text-white" />
                ) : (
                  <Heart className="h-8 w-8 text-white" />
                )}
              </div>
            </div>
            <h2 className="text-2xl mb-3 text-gray-900 font-bold">
              {userType === 'student' ? 'Student Registration' : 'Counsellor Registration'} ✦
            </h2>
            <p className="text-sm text-gray-600">
              {userType === 'student' 
                ? 'Create your confidential account (optional - you can use MindEase anonymously)'
                : 'Join our verified counsellor network'
              }
            </p>
          </div>

          <div className="space-y-5">
            {/* Basic Information */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="firstName" className="text-sm font-medium text-gray-900">
                  {t('auth.firstName') || 'First Name'}
                </Label>
                <Input
                  id="firstName"
                  placeholder="John"
                  className="rounded-xl border-2 h-11 bg-white border-gray-300 text-gray-900"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="lastName" className="text-sm font-medium text-gray-900">
                  {t('auth.lastName') || 'Last Name'}
                </Label>
                <Input
                  id="lastName"
                  placeholder="Doe"
                  className="rounded-xl border-2 h-11 bg-white border-gray-300 text-gray-900"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="username" className="text-sm font-medium text-gray-900">
                {t('auth.username') || 'Username'}
              </Label>
              <Input
                id="username"
                type="text"
                placeholder="Choose a unique username"
                className="rounded-xl border-2 h-11 bg-white border-gray-300 text-gray-900"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email" className="text-sm font-medium text-gray-900">
                {t('auth.email') || 'Email'}
              </Label>
              <Input
                id="email"
                type="email"
                placeholder={userType === 'student' ? 'your.email@college.edu' : 'your.email@domain.com'}
                className="rounded-xl border-2 h-11 bg-white border-gray-300 text-gray-900"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password" className="text-sm font-medium text-gray-900">
                Create Password
              </Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  placeholder="Create a strong password"
                  className="rounded-xl border-2 h-11 pr-12 bg-white border-gray-300 text-gray-900"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="absolute right-0 top-0 h-full px-4 hover:bg-transparent rounded-xl text-gray-600"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? (
                    <EyeOff className="h-5 w-5" />
                  ) : (
                    <Eye className="h-5 w-5" />
                  )}
                </Button>
              </div>
            </div>

            {/* Additional fields based on user type */}
            {userType === 'student' ? (
              <>
                <div className="space-y-2">
                  <Label htmlFor="college" className="text-sm font-medium text-gray-900">
                    {t('auth.college') || 'College'}
                  </Label>
                  <Input
                    id="college"
                    placeholder="Your college name"
                    className="rounded-xl border-2 h-11 bg-white border-gray-300 text-gray-900"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="year" className="text-sm font-medium text-gray-900">
                    {t('auth.year') || 'Year'}
                  </Label>
                  <Select>
                    <SelectTrigger className="rounded-xl border-2 h-11 bg-white border-gray-300 text-gray-900">
                      <SelectValue placeholder="Select your year" />
                    </SelectTrigger>
                    <SelectContent className="bg-white border border-gray-300">
                      <SelectItem value="1st" className="text-gray-900">1st Year</SelectItem>
                      <SelectItem value="2nd" className="text-gray-900">2nd Year</SelectItem>
                      <SelectItem value="3rd" className="text-gray-900">3rd Year</SelectItem>
                      <SelectItem value="4th" className="text-gray-900">4th Year</SelectItem>
                      <SelectItem value="masters" className="text-gray-900">Master's</SelectItem>
                      <SelectItem value="phd" className="text-gray-900">PhD</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </>
            ) : (
              <>
                <div className="space-y-2">
                  <Label htmlFor="license" className="text-sm font-medium text-gray-900">
                    {t('auth.license') || 'License'}
                  </Label>
                  <Input
                    id="license"
                    placeholder="Your professional license number"
                    className="rounded-xl border-2 h-11 bg-white border-gray-300 text-gray-900"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="specialization" className="text-sm font-medium text-gray-900">
                    {t('auth.specialization') || 'Specialization'}
                  </Label>
                  <Select>
                    <SelectTrigger className="rounded-xl border-2 h-11 bg-white border-gray-300 text-gray-900">
                      <SelectValue placeholder="Select your specialization" />
                    </SelectTrigger>
                    <SelectContent className="bg-white border border-gray-300">
                      <SelectItem value="clinical" className="text-gray-900">Clinical Psychology</SelectItem>
                      <SelectItem value="counseling" className="text-gray-900">Counseling Psychology</SelectItem>
                      <SelectItem value="student-affairs" className="text-gray-900">Student Affairs</SelectItem>
                      <SelectItem value="psychiatry" className="text-gray-900">Psychiatry</SelectItem>
                      <SelectItem value="social-work" className="text-gray-900">Social Work</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </>
            )}

            {/* Terms and Privacy */}
            <div className="flex items-start space-x-3">
              <Checkbox 
                id="terms" 
                checked={agreeToTerms}
                onCheckedChange={(checked) => setAgreeToTerms(checked as boolean)}
                className="mt-1"
              />
              <Label htmlFor="terms" className="text-xs leading-relaxed text-gray-700">
                {t('auth.terms') || 'I agree to the Terms of Service and Privacy Policy'}
              </Label>
            </div>

            <Button 
              className="w-full rounded-xl text-white shadow-lg hover:shadow-2xl transition-all duration-300 h-12 text-lg hover:scale-105"
              disabled={!agreeToTerms}
              style={{ 
                background: userType === 'student' 
                  ? 'linear-gradient(135deg, rgba(147, 197, 253, 0.8) 0%, rgba(59, 130, 246, 0.9) 50%, rgba(37, 99, 235, 0.8) 100%)'
                  : 'var(--mindease-gradient-warm)'
              }}
            >
              {t('auth.createAccount') || 'Create Account'} ✧
            </Button>

            {/* Privacy assurance for students */}
            {userType === 'student' && (
              <div className="bg-blue-50 border border-blue-200 rounded-2xl p-5">
                <div className="flex items-center space-x-3 mb-3">
                  <ShieldCheck className="h-5 w-5 text-blue-600" />
                  <span className="text-sm font-medium text-blue-900">
                    {t('auth.privacyProtected') || 'Privacy Protected'} ✦
                  </span>
                </div>
                <ul className="text-xs space-y-1 text-blue-800">
                  <li>✧ Your data is encrypted and confidential</li>
                  <li>✧ You can delete your account anytime</li>
                  <li>✧ Anonymous usage option always available</li>
                </ul>
              </div>
            )}

            {/* Anonymous option for students */}
            {userType === 'student' && (
              <div className="text-center pt-4 border-t border-gray-200">
                <Button 
                  variant="ghost" 
                  size="sm"
                  className="text-xs rounded-xl hover:bg-gray-100 text-gray-600"
                >
                  <UserCheck className="h-4 w-4 mr-2" />
                  {t('auth.anonymousOption') || 'Continue Anonymously'} ✩
                </Button>
              </div>
            )}
          </div>
        </>
      )}
    </CustomModal>
  );
}